#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 09:53:10 2018

@author: jacopo baggio and jacob freeman

This script allows for the synch analysis of human energy and solar energy between 10400 and 400 years ago. 
The figure numbers here do not reflect those in the paper but reflect the figures within this script.

This script is based on calibrated dates and 100 years bins, two other scripts should be uses with this, those are for
calibrated dates at 100 year bins and 200 year bin. Last sensitivity analysis is done with raw dates (not calibrated)

Notes and known issues: 
    the np.nanmean procedure to calculate avg synch is tricky, seems to work only sometimes, 
    and sometime does not recognizes the nan values and substitute them to 0 lowering artificially the synch.
    If that happens, one need to rerun that portion of the code and make sure that l800, l900 and l1000 contain nan values.
    And that those values are transferred to sy800, sy900 and sy1000.

"""

import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.signal as sig
import os

calib = ('/Users/jacopo/Documents/A_STUDI/AAA_work/CoupledInfra_LongTermVariance/HumanSyncing/PNASData/calibdata_300.dta')

wdir2 =('/Users/jacopo/Documents/A_STUDI/AAA_work/CoupledInfra_LongTermVariance/HumanSyncing/PNASFigs/Bin300')
os.chdir(wdir2)

#Loading data With Calibrated Dates
dfcalib = pd.read_stata(calib)


#Compute  total energy avg and then compute per continent the difference between sunspots and calibrated data
tot = dfcalib.ariz + dfcalib.cali + dfcalib.colo + dfcalib.nmex + dfcalib.neva + dfcalib.utah + dfcalib.wyom + dfcalib.eng + dfcalib.wal + dfcalib.scot + dfcalib.ire + dfcalib.chile + dfcalib.aus
mtot = tot / 13
sun = dfcalib.sun
time = dfcalib.bp 

 
#Analysis and Figure for 100 year bin (Scroll down for 200 and 300 year binned data calibrated, and for raw data for Western US)

#Generating PLV (and kuramot order parameter) for the whole 10,000 btw areas, btw continents and btw areas and sun and btw continents and sun

#Generating hilbert transform and taking angle to assess PLV pairwise and total synch parameter
har = np.angle (sig.hilbert(dfcalib.ariz)) 
hca = np.angle (sig.hilbert(dfcalib.cali))
hco = np.angle (sig.hilbert(dfcalib.colo)) 
hnm = np.angle (sig.hilbert(dfcalib.nmex))
hnv = np.angle (sig.hilbert(dfcalib.neva)) 
hut = np.angle (sig.hilbert(dfcalib.utah))
hwy = np.angle (sig.hilbert(dfcalib.wyom)) 
hen = np.angle (sig.hilbert(dfcalib.eng)) 
hwa = np.angle (sig.hilbert(dfcalib.wal))
hsc = np.angle (sig.hilbert(dfcalib.scot))
hir = np.angle(sig.hilbert(dfcalib.ire))
hau = np.angle(sig.hilbert(dfcalib.aus))   
huk = np.angle(sig.hilbert(dfcalib.uk))
hus = np.angle(sig.hilbert(dfcalib.usa))
hch = np.angle(sig.hilbert(dfcalib.chile))    
hsun = np.angle(sig.hilbert(dfcalib.sun))

#create empty matrices for synch heatmaps and to store data
phas =[]
tsun = []
regi =[]
resun=[]

#Calcualte Pairwise SYNCHS over the last 10,000 years
#Calculate Synchronization over the last 10,000 years by areas (for figures 1,2,3 and 4)
phas= np.zeros((13,13))
phas[1][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hca)))/np.size(har))
phas[2][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hco)))/np.size(har))
phas[3][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hnm)))/np.size(har))
phas[4][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hnv)))/np.size(har))
phas[5][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hut)))/np.size(har))
phas[6][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hwy)))/np.size(har))
phas[7][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hch)))/np.size(har))
phas[8][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hen)))/np.size(har))
phas[9][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hwa)))/np.size(har))
phas[10][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hsc)))/np.size(har))
phas[11][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hir)))/np.size(har))
phas[12][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hau)))/np.size(har))

phas[2][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hco)))/np.size(hca))
phas[3][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hnm)))/np.size(hca))
phas[4][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hnv)))/np.size(hca))
phas[5][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hut)))/np.size(hca))
phas[6][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hwy)))/np.size(hca))
phas[7][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hch)))/np.size(hca))
phas[8][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hen)))/np.size(hca))
phas[9][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hwa)))/np.size(hca))
phas[10][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hsc)))/np.size(hca))
phas[11][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hir)))/np.size(hca))
phas[12][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hau)))/np.size(hca))

phas[3][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hnm)))/np.size(hco))
phas[4][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hnv)))/np.size(hco))
phas[5][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hut)))/np.size(hco))
phas[6][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hwy)))/np.size(hco))
phas[7][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hch)))/np.size(hco))
phas[8][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hen)))/np.size(hco))
phas[9][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hwa)))/np.size(hco))
phas[10][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hsc)))/np.size(hco))
phas[11][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hir)))/np.size(hco))
phas[12][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hau)))/np.size(hco))

phas[4][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hnv)))/np.size(hnm))
phas[5][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hut)))/np.size(hnm))
phas[6][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hwy)))/np.size(hnm))
phas[7][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hch)))/np.size(hnm))
phas[8][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hen)))/np.size(hnm))
phas[9][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hwa)))/np.size(hnm))
phas[10][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hsc)))/np.size(hnm))
phas[11][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hir)))/np.size(hnm))
phas[12][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hau)))/np.size(hnm))
       
phas[5][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hut)))/np.size(hnv))
phas[6][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hwy)))/np.size(hnv))
phas[7][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hch)))/np.size(hnv))
phas[8][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hen)))/np.size(hnv))
phas[9][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hwa)))/np.size(hnv))
phas[10][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hsc)))/np.size(hnv))
phas[11][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hir)))/np.size(hnv))
phas[12][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hau)))/np.size(hnv))
    
phas[6][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hwy)))/np.size(hut))
phas[7][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hch)))/np.size(hut))
phas[8][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hen)))/np.size(hut))
phas[9][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hwa)))/np.size(hut))
phas[10][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hsc)))/np.size(hut))
phas[11][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hir)))/np.size(hut))
phas[12][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hau)))/np.size(hut))
    
phas[7][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hch)))/np.size(hwy))
phas[8][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hen)))/np.size(hwy))
phas[9][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hwa)))/np.size(hwy))
phas[10][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hsc)))/np.size(hwy))
phas[11][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hir)))/np.size(hwy))
phas[12][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hau)))/np.size(hwy))
    
phas[8][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hen)))/np.size(hch))
phas[9][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hwa)))/np.size(hch))
phas[10][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hsc)))/np.size(hch))
phas[11][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hir)))/np.size(hch))
phas[12][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hau)))/np.size(hch))   

phas[9][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hwa)))/np.size(hen))
phas[10][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hsc)))/np.size(hen))
phas[11][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hir)))/np.size(hen))
phas[12][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hau)))/np.size(hen))    
    
phas[10][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hsc)))/np.size(hwa))
phas[11][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hir)))/np.size(hwa))
phas[12][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hau)))/np.size(hwa)) 

phas[11][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsc-hir)))/np.size(hsc))
phas[12][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsc-hau)))/np.size(hsc)) 
    
phas[12][11]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hir-hau)))/np.size(hir)) 

#Calculate Synchronization between regions 
regi= np.zeros((4,4))
regi[1][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hus-huk)))/np.size(hus))
regi[2][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hus-hau)))/np.size(hus))
regi[3][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hus-hch)))/np.size(hus))

regi[2][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(huk-hau)))/np.size(huk))
regi[3][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(huk-hch)))/np.size(huk))

regi[3][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hau)))/np.size(hch))


#Calculate Synchronization between areas and sun forcing
tsun= np.zeros((1,13))
tsun[0][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-har)))/np.size(har))
tsun[0][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hca)))/np.size(har))
tsun[0][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hco)))/np.size(har))
tsun[0][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hnm)))/np.size(har))
tsun[0][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hnv)))/np.size(har))
tsun[0][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hut)))/np.size(har))
tsun[0][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hwy)))/np.size(har))
tsun[0][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hch)))/np.size(har))
tsun[0][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hen)))/np.size(har))
tsun[0][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hwa)))/np.size(har))
tsun[0][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hsc)))/np.size(har))
tsun[0][11]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hir)))/np.size(har))
tsun[0][12]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hau)))/np.size(har))

#Calculate Synchronization between regions and sun forcing
resun= np.zeros((1,4))
resun[0][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hus)))/np.size(hsun))
resun[0][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-huk)))/np.size(hsun))
resun[0][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hau)))/np.size(hsun))
resun[0][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hch)))/np.size(hsun))


#Calculate Moving Window at 800,900 and 1000 years 
#sorting file for country and year for calibrated dates
dfcalib = dfcalib.sort_values(['bp'])
#create unique list of names to assess synching at 800, 900 and 1000 year level (moving window)
ucalib8 = dfcalib.bin800.unique()
ucalib9 = dfcalib.bin900.unique()
ucalib10 = dfcalib.bin1000.unique()


#Generate dictionaries to assess phase locking between areas and sun with intervals
data800 = {elem : pd.DataFrame for elem in ucalib8}
for key in data800.keys():
    data800[key] = dfcalib[['sun', 'eng','wal','scot','ire','aus','uk','usa', 'ariz','cali','colo','nmex','neva','utah','wyom','chile', 'bin800']][dfcalib.bin800 == key]

data900 = {elem : pd.DataFrame for elem in ucalib9}
for key in data900.keys():
    data900[key] = dfcalib[['sun', 'eng','wal','scot','ire','aus','uk','usa', 'ariz','cali','colo','nmex','neva','utah','wyom','chile', 'bin900']][dfcalib.bin900 == key]

data1000 = {elem : pd.DataFrame for elem in ucalib10}
for key in data1000.keys():
    data1000[key] = dfcalib[['sun', 'eng','wal','scot','ire','aus','uk','usa', 'ariz','cali','colo','nmex','neva','utah','wyom','chile', 'bin1000']][dfcalib.bin1000 == key]

#create empty dictionaries to store results of the analysis (PLV values)
ph800 = {}
ph900 = {}
ph1000 = {}

tsun800= {}
tsun900= {}
tsun1000= {}

i = 0
for key in data800:
    ari1 = data800[key]['ariz']
    cali1 = data800[key]['cali']
    colo1 = data800[key]['colo']
    nmex1 = data800[key]['nmex']
    neva1 = data800[key]['neva']
    utah1 = data800[key]['utah']
    wyom1 = data800[key]['wyom']
    chil1 = data800[key]['chile']
    eng1 = data800[key]['eng']
    wal1 = data800[key]['wal']
    scot1 = data800[key]['scot']
    ire1 = data800[key]['ire']
    aus1 = data800[key]['aus']    
    uk1 = data800[key]['uk']
    usa1 = data800[key]['usa']
    tsun1 = data800[key]['sun']

    
    har = np.angle(sig.hilbert(ari1))
    hca = np.angle(sig.hilbert(cali1))
    hco = np.angle(sig.hilbert(colo1))
    hnm = np.angle(sig.hilbert(nmex1))
    hnv = np.angle(sig.hilbert(neva1))
    hut = np.angle(sig.hilbert(utah1))
    hwy = np.angle(sig.hilbert(wyom1))
    hch = np.angle(sig.hilbert(chil1))    
    hen = np.angle(sig.hilbert(eng1))
    hwa = np.angle(sig.hilbert(wal1))
    hsc = np.angle(sig.hilbert(scot1))
    hir = np.angle(sig.hilbert(ire1))
    hau = np.angle(sig.hilbert(aus1))    
    huk = np.angle(sig.hilbert(uk1))
    hus = np.angle(sig.hilbert(usa1))
    hsun = np.angle(sig.hilbert(tsun1))

    ph800[key]= np.zeros((13,13))
    ph800[key][1][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hca)))/np.size(har))
    ph800[key][2][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hco)))/np.size(har))
    ph800[key][3][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hnm)))/np.size(har))
    ph800[key][4][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hnv)))/np.size(har))
    ph800[key][5][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hut)))/np.size(har))
    ph800[key][6][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hwy)))/np.size(har))
    ph800[key][7][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hch)))/np.size(har))
    ph800[key][8][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hen)))/np.size(har))
    ph800[key][9][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hwa)))/np.size(har))
    ph800[key][10][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hsc)))/np.size(har))
    ph800[key][11][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hir)))/np.size(har))
    ph800[key][12][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hau)))/np.size(har))
    ph800[key][2][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hco)))/np.size(hca))
    ph800[key][3][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hnm)))/np.size(hca))
    ph800[key][4][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hnv)))/np.size(hca))
    ph800[key][5][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hut)))/np.size(hca))
    ph800[key][6][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hwy)))/np.size(hca))
    ph800[key][7][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hch)))/np.size(hca))
    ph800[key][8][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hen)))/np.size(hca))
    ph800[key][9][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hwa)))/np.size(hca))
    ph800[key][10][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hsc)))/np.size(hca))
    ph800[key][11][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hir)))/np.size(hca))
    ph800[key][12][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hau)))/np.size(hca))
    ph800[key][3][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hnm)))/np.size(hco))
    ph800[key][4][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hnv)))/np.size(hco))
    ph800[key][5][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hut)))/np.size(hco))
    ph800[key][6][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hwy)))/np.size(hco))
    ph800[key][7][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hch)))/np.size(hco))
    ph800[key][8][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hen)))/np.size(hco))
    ph800[key][9][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hwa)))/np.size(hco))
    ph800[key][10][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hsc)))/np.size(hco))
    ph800[key][11][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hir)))/np.size(hco))
    ph800[key][12][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hau)))/np.size(hco))
    ph800[key][4][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hnv)))/np.size(hnm))
    ph800[key][5][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hut)))/np.size(hnm))
    ph800[key][6][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hwy)))/np.size(hnm))
    ph800[key][7][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hch)))/np.size(hnm))
    ph800[key][8][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hen)))/np.size(hnm))
    ph800[key][9][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hwa)))/np.size(hnm))
    ph800[key][10][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hsc)))/np.size(hnm))
    ph800[key][11][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hir)))/np.size(hnm))
    ph800[key][12][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hau)))/np.size(hnm))   
    ph800[key][5][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hut)))/np.size(hnv))
    ph800[key][6][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hwy)))/np.size(hnv))
    ph800[key][7][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hch)))/np.size(hnv))
    ph800[key][8][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hen)))/np.size(hnv))
    ph800[key][9][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hwa)))/np.size(hnv))
    ph800[key][10][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hsc)))/np.size(hnv))
    ph800[key][11][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hir)))/np.size(hnv))
    ph800[key][12][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hau)))/np.size(hnv))
    ph800[key][6][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hwy)))/np.size(hut))
    ph800[key][7][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hch)))/np.size(hut))
    ph800[key][8][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hen)))/np.size(hut))
    ph800[key][9][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hwa)))/np.size(hut))
    ph800[key][10][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hsc)))/np.size(hut))
    ph800[key][11][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hir)))/np.size(hut))
    ph800[key][12][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hau)))/np.size(hut))
    ph800[key][7][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hch)))/np.size(hwy))
    ph800[key][8][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hen)))/np.size(hwy))
    ph800[key][9][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hwa)))/np.size(hwy))
    ph800[key][10][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hsc)))/np.size(hwy))
    ph800[key][11][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hir)))/np.size(hwy))
    ph800[key][12][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hau)))/np.size(hwy))
    ph800[key][8][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hen)))/np.size(hch))
    ph800[key][9][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hwa)))/np.size(hch))
    ph800[key][10][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hsc)))/np.size(hch))
    ph800[key][11][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hir)))/np.size(hch))
    ph800[key][12][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hau)))/np.size(hch))   
    ph800[key][9][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hwa)))/np.size(hen))
    ph800[key][10][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hsc)))/np.size(hen))
    ph800[key][11][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hir)))/np.size(hen))
    ph800[key][12][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hau)))/np.size(hen))    
    ph800[key][10][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hsc)))/np.size(hwa))
    ph800[key][11][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hir)))/np.size(hwa))
    ph800[key][12][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hau)))/np.size(hwa)) 
    ph800[key][11][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsc-hir)))/np.size(hsc))
    ph800[key][12][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsc-hau)))/np.size(hsc)) 
    ph800[key][12][11]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hir-hau)))/np.size(hir)) 
 
    tsun800[key]= np.zeros((1,13))
    tsun800[key][0][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-har)))/np.size(har))
    tsun800[key][0][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hca)))/np.size(har))
    tsun800[key][0][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hco)))/np.size(har))
    tsun800[key][0][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hnm)))/np.size(har))
    tsun800[key][0][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hnv)))/np.size(har))
    tsun800[key][0][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hut)))/np.size(har))
    tsun800[key][0][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hwy)))/np.size(har))
    tsun800[key][0][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hch)))/np.size(har))
    tsun800[key][0][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hen)))/np.size(har))
    tsun800[key][0][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hwa)))/np.size(har))
    tsun800[key][0][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hsc)))/np.size(har))
    tsun800[key][0][11]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hir)))/np.size(har))
    tsun800[key][0][12]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hau)))/np.size(har))
    
    i+=1
    
i = 0
for key in data900:
    ari1 = data900[key]['ariz']
    cali1 = data900[key]['cali']
    colo1 = data900[key]['colo']
    nmex1 = data900[key]['nmex']
    neva1 = data900[key]['neva']
    utah1 = data900[key]['utah']
    wyom1 = data900[key]['wyom']
    chil1 = data900[key]['chile']
    eng1 = data900[key]['eng']
    wal1 = data900[key]['wal']
    scot1 = data900[key]['scot']
    ire1 = data900[key]['ire']
    aus1 = data900[key]['aus']    
    uk1 = data900[key]['uk']
    usa1 = data900[key]['usa']
    tsun1 = data900[key]['sun']

    har = np.angle(sig.hilbert(ari1))
    hca = np.angle(sig.hilbert(cali1))
    hco = np.angle(sig.hilbert(colo1))
    hnm = np.angle(sig.hilbert(nmex1))
    hnv = np.angle(sig.hilbert(neva1))
    hut = np.angle(sig.hilbert(utah1))
    hwy = np.angle(sig.hilbert(wyom1))
    hch = np.angle(sig.hilbert(chil1))    
    hen = np.angle(sig.hilbert(eng1))
    hwa = np.angle(sig.hilbert(wal1))
    hsc = np.angle(sig.hilbert(scot1))
    hir = np.angle(sig.hilbert(ire1))
    hau = np.angle(sig.hilbert(aus1))    
    huk = np.angle(sig.hilbert(uk1))
    hus = np.angle(sig.hilbert(usa1))
    hsun = np.angle(sig.hilbert(tsun1))

    ph900[key]= np.zeros((13,13))
    ph900[key][1][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hca)))/np.size(har))
    ph900[key][2][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hco)))/np.size(har))
    ph900[key][3][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hnm)))/np.size(har))
    ph900[key][4][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hnv)))/np.size(har))
    ph900[key][5][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hut)))/np.size(har))
    ph900[key][6][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hwy)))/np.size(har))
    ph900[key][7][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hch)))/np.size(har))
    ph900[key][8][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hen)))/np.size(har))
    ph900[key][9][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hwa)))/np.size(har))
    ph900[key][10][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hsc)))/np.size(har))
    ph900[key][11][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hir)))/np.size(har))
    ph900[key][12][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hau)))/np.size(har))
    ph900[key][2][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hco)))/np.size(hca))
    ph900[key][3][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hnm)))/np.size(hca))
    ph900[key][4][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hnv)))/np.size(hca))
    ph900[key][5][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hut)))/np.size(hca))
    ph900[key][6][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hwy)))/np.size(hca))
    ph900[key][7][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hch)))/np.size(hca))
    ph900[key][8][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hen)))/np.size(hca))
    ph900[key][9][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hwa)))/np.size(hca))
    ph900[key][10][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hsc)))/np.size(hca))
    ph900[key][11][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hir)))/np.size(hca))
    ph900[key][12][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hau)))/np.size(hca))
    ph900[key][3][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hnm)))/np.size(hco))
    ph900[key][4][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hnv)))/np.size(hco))
    ph900[key][5][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hut)))/np.size(hco))
    ph900[key][6][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hwy)))/np.size(hco))
    ph900[key][7][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hch)))/np.size(hco))
    ph900[key][8][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hen)))/np.size(hco))
    ph900[key][9][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hwa)))/np.size(hco))
    ph900[key][10][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hsc)))/np.size(hco))
    ph900[key][11][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hir)))/np.size(hco))
    ph900[key][12][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hau)))/np.size(hco))
    ph900[key][4][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hnv)))/np.size(hnm))
    ph900[key][5][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hut)))/np.size(hnm))
    ph900[key][6][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hwy)))/np.size(hnm))
    ph900[key][7][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hch)))/np.size(hnm))
    ph900[key][8][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hen)))/np.size(hnm))
    ph900[key][9][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hwa)))/np.size(hnm))
    ph900[key][10][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hsc)))/np.size(hnm))
    ph900[key][11][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hir)))/np.size(hnm))
    ph900[key][12][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hau)))/np.size(hnm))   
    ph900[key][5][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hut)))/np.size(hnv))
    ph900[key][6][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hwy)))/np.size(hnv))
    ph900[key][7][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hch)))/np.size(hnv))
    ph900[key][8][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hen)))/np.size(hnv))
    ph900[key][9][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hwa)))/np.size(hnv))
    ph900[key][10][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hsc)))/np.size(hnv))
    ph900[key][11][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hir)))/np.size(hnv))
    ph900[key][12][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hau)))/np.size(hnv))
    ph900[key][6][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hwy)))/np.size(hut))
    ph900[key][7][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hch)))/np.size(hut))
    ph900[key][8][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hen)))/np.size(hut))
    ph900[key][9][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hwa)))/np.size(hut))
    ph900[key][10][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hsc)))/np.size(hut))
    ph900[key][11][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hir)))/np.size(hut))
    ph900[key][12][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hau)))/np.size(hut))
    ph900[key][7][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hch)))/np.size(hwy))
    ph900[key][8][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hen)))/np.size(hwy))
    ph900[key][9][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hwa)))/np.size(hwy))
    ph900[key][10][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hsc)))/np.size(hwy))
    ph900[key][11][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hir)))/np.size(hwy))
    ph900[key][12][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hau)))/np.size(hwy))
    ph900[key][8][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hen)))/np.size(hch))
    ph900[key][9][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hwa)))/np.size(hch))
    ph900[key][10][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hsc)))/np.size(hch))
    ph900[key][11][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hir)))/np.size(hch))
    ph900[key][12][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hau)))/np.size(hch))   
    ph900[key][9][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hwa)))/np.size(hen))
    ph900[key][10][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hsc)))/np.size(hen))
    ph900[key][11][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hir)))/np.size(hen))
    ph900[key][12][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hau)))/np.size(hen))    
    ph900[key][10][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hsc)))/np.size(hwa))
    ph900[key][11][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hir)))/np.size(hwa))
    ph900[key][12][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hau)))/np.size(hwa)) 
    ph900[key][11][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsc-hir)))/np.size(hsc))
    ph900[key][12][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsc-hau)))/np.size(hsc)) 
    ph900[key][12][11]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hir-hau)))/np.size(hir)) 
 
    tsun900[key]= np.zeros((1,13))
    tsun900[key][0][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-har)))/np.size(har))
    tsun900[key][0][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hca)))/np.size(har))
    tsun900[key][0][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hco)))/np.size(har))
    tsun900[key][0][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hnm)))/np.size(har))
    tsun900[key][0][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hnv)))/np.size(har))
    tsun900[key][0][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hut)))/np.size(har))
    tsun900[key][0][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hwy)))/np.size(har))
    tsun900[key][0][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hch)))/np.size(har))
    tsun900[key][0][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hen)))/np.size(har))
    tsun900[key][0][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hwa)))/np.size(har))
    tsun900[key][0][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hsc)))/np.size(har))
    tsun900[key][0][11]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hir)))/np.size(har))
    tsun900[key][0][12]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hau)))/np.size(har))
    
    i+=1
#this checks for order parameter for every 1000 years
i = 0
for key in data1000:
    ari1 = data1000[key]['ariz']
    cali1 = data1000[key]['cali']
    colo1 = data1000[key]['colo']
    nmex1 = data1000[key]['nmex']
    neva1 = data1000[key]['neva']
    utah1 = data1000[key]['utah']
    wyom1 = data1000[key]['wyom']
    chil1 = data1000[key]['chile']
    eng1 = data1000[key]['eng']
    wal1 = data1000[key]['wal']
    scot1 = data1000[key]['scot']
    ire1 = data1000[key]['ire']
    aus1 = data1000[key]['aus']
    uk1 = data1000[key]['uk']
    usa1 = data1000[key]['usa']
    tsun1 = data1000[key]['sun']
    
    har = np.angle(sig.hilbert(ari1))
    hca = np.angle(sig.hilbert(cali1))
    hco = np.angle(sig.hilbert(colo1))
    hnm = np.angle(sig.hilbert(nmex1))
    hnv = np.angle(sig.hilbert(neva1))
    hut = np.angle(sig.hilbert(utah1))
    hwy = np.angle(sig.hilbert(wyom1))
    hch = np.angle(sig.hilbert(chil1))
    hen = np.angle(sig.hilbert(eng1))
    hwa = np.angle(sig.hilbert(wal1))
    hsc = np.angle(sig.hilbert(scot1))
    hir = np.angle(sig.hilbert(ire1))
    hau = np.angle(sig.hilbert(aus1))
    huk = np.angle(sig.hilbert(uk1))
    hus = np.angle(sig.hilbert(usa1))
    hsun = np.angle(sig.hilbert(tsun1))

    ph1000[key]= np.zeros((13,13))
    ph1000[key][1][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hca)))/np.size(har))
    ph1000[key][2][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hco)))/np.size(har))
    ph1000[key][3][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hnm)))/np.size(har))
    ph1000[key][4][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hnv)))/np.size(har))
    ph1000[key][5][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hut)))/np.size(har))
    ph1000[key][6][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hwy)))/np.size(har))
    ph1000[key][7][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hch)))/np.size(har))
    ph1000[key][8][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hen)))/np.size(har))
    ph1000[key][9][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hwa)))/np.size(har))
    ph1000[key][10][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hsc)))/np.size(har))
    ph1000[key][11][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hir)))/np.size(har))
    ph1000[key][12][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(har-hau)))/np.size(har))
    ph1000[key][2][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hco)))/np.size(hca))
    ph1000[key][3][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hnm)))/np.size(hca))
    ph1000[key][4][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hnv)))/np.size(hca))
    ph1000[key][5][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hut)))/np.size(hca))
    ph1000[key][6][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hwy)))/np.size(hca))
    ph1000[key][7][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hch)))/np.size(hca))
    ph1000[key][8][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hen)))/np.size(hca))
    ph1000[key][9][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hwa)))/np.size(hca))
    ph1000[key][10][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hsc)))/np.size(hca))
    ph1000[key][11][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hir)))/np.size(hca))
    ph1000[key][12][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hca-hau)))/np.size(hca))
    ph1000[key][3][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hnm)))/np.size(hco))
    ph1000[key][4][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hnv)))/np.size(hco))
    ph1000[key][5][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hut)))/np.size(hco))
    ph1000[key][6][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hwy)))/np.size(hco))
    ph1000[key][7][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hch)))/np.size(hco))
    ph1000[key][8][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hen)))/np.size(hco))
    ph1000[key][9][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hwa)))/np.size(hco))
    ph1000[key][10][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hsc)))/np.size(hco))
    ph1000[key][11][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hir)))/np.size(hco))
    ph1000[key][12][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hco-hau)))/np.size(hco))
    ph1000[key][4][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hnv)))/np.size(hnm))
    ph1000[key][5][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hut)))/np.size(hnm))
    ph1000[key][6][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hwy)))/np.size(hnm))
    ph1000[key][7][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hch)))/np.size(hnm))
    ph1000[key][8][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hen)))/np.size(hnm))
    ph1000[key][9][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hwa)))/np.size(hnm))
    ph1000[key][10][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hsc)))/np.size(hnm))
    ph1000[key][11][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hir)))/np.size(hnm))
    ph1000[key][12][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnm-hau)))/np.size(hnm))
    ph1000[key][5][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hut)))/np.size(hnv))
    ph1000[key][6][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hwy)))/np.size(hnv))
    ph1000[key][7][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hch)))/np.size(hnv))
    ph1000[key][8][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hen)))/np.size(hnv))
    ph1000[key][9][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hwa)))/np.size(hnv))
    ph1000[key][10][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hsc)))/np.size(hnv))
    ph1000[key][11][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hir)))/np.size(hnv))
    ph1000[key][12][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hnv-hau)))/np.size(hnv))
    ph1000[key][6][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hwy)))/np.size(hut))
    ph1000[key][7][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hch)))/np.size(hut))
    ph1000[key][8][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hen)))/np.size(hut))
    ph1000[key][9][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hwa)))/np.size(hut))
    ph1000[key][10][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hsc)))/np.size(hut))
    ph1000[key][11][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hir)))/np.size(hut))
    ph1000[key][12][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hut-hau)))/np.size(hut))
    ph1000[key][7][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hch)))/np.size(hwy))
    ph1000[key][8][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hen)))/np.size(hwy))
    ph1000[key][9][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hwa)))/np.size(hwy))
    ph1000[key][10][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hsc)))/np.size(hwy))
    ph1000[key][11][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hir)))/np.size(hwy))
    ph1000[key][12][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwy-hau)))/np.size(hwy))
    ph1000[key][8][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hen)))/np.size(hch))
    ph1000[key][9][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hwa)))/np.size(hch))
    ph1000[key][10][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hsc)))/np.size(hch))
    ph1000[key][11][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hir)))/np.size(hch))
    ph1000[key][12][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hch-hau)))/np.size(hch))   
    ph1000[key][9][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hwa)))/np.size(hen))
    ph1000[key][10][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hsc)))/np.size(hen))
    ph1000[key][11][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hir)))/np.size(hen))
    ph1000[key][12][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hen-hau)))/np.size(hen))    
    ph1000[key][10][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hsc)))/np.size(hwa))
    ph1000[key][11][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hir)))/np.size(hwa))
    ph1000[key][12][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hwa-hau)))/np.size(hwa)) 
    ph1000[key][11][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsc-hir)))/np.size(hsc))
    ph1000[key][12][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsc-hau)))/np.size(hsc)) 
    ph1000[key][12][11]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hir-hau)))/np.size(hir)) 
 
    tsun1000[key]= np.zeros((1,13))
    tsun1000[key][0][0]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-har)))/np.size(har))
    tsun1000[key][0][1]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hca)))/np.size(har))
    tsun1000[key][0][2]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hco)))/np.size(har))
    tsun1000[key][0][3]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hnm)))/np.size(har))
    tsun1000[key][0][4]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hnv)))/np.size(har))
    tsun1000[key][0][5]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hut)))/np.size(har))
    tsun1000[key][0][6]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hwy)))/np.size(har))
    tsun1000[key][0][7]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hch)))/np.size(har))
    tsun1000[key][0][8]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hen)))/np.size(har))
    tsun1000[key][0][9]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hwa)))/np.size(har))
    tsun1000[key][0][10]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hsc)))/np.size(har))
    tsun1000[key][0][11]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hir)))/np.size(har))
    tsun1000[key][0][12]= 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hsun-hau)))/np.size(har))
    
    i+=1

#transform dictionary in ordered list for figure purposes
l800 = sorted(ph800.items())
l900 = sorted(ph900.items())
l1000 = sorted(ph1000.items())

t800 = sorted(tsun800.items())
t900 = sorted(tsun900.items())
t1000 = sorted(tsun1000.items()) 

#unzip lists so that y contain arrays, and x titles for graphs (only human energy): makes it easier to graph automatically (fig 5,6,7) 
t8,s8=map(list, zip(*l800))
t9,s9=map(list, zip(*l900))
t1,s1=map(list, zip(*l1000))

#unzip lists so that y contain arrays, and x titles for graphs (with sun energy): makes it easier to graph automatically (fig 9) 
tt8,st8=map(list, zip(*t800))
tt9,st9=map(list, zip(*t900))
tt1,st1=map(list, zip(*t1000))

#create empty list to use for avg synch values to plot (figure 8)
sy800=[0]*len(t8)
sy900=[0]*len(t9)
sy1000=[0]*len(t1)

#create empty array to use for avg synch values to plot (figure 9)
syt800 = np.zeros((len(tt8),13))
syt900 = np.zeros((len(tt9),13))
syt1000 = np.zeros((len(tt1),13))

#create empty lists for avg solar synch values overall (figure 10)
sys800=[0]*len(tt8)
sys900=[0]*len(tt9)
sys1000=[0]*len(tt1)

#generate average phase synch with sun energy for 800,900 and 1000  (for fig 9)
for i in range(0,len(tt8)):
    syt800[i]=st8[i] 
for i in range(0,len(tt9)):
    syt900[i]=st9[i] 
for i in range(0,len(tt1)):
    syt1000[i]=st1[i]
    
#generate average phase synch for 800,900 and 1000 year moving window (for fig 8)
#only use portion of triangle, so need to put avg * 2 (to avoid the 0 that should be nan to artificially reduce the synch values)

for i in range(0,len(t8)):
    tit = str(t8[i])
    tofig2 = s8[i]
    sy800[i] = np.nanmean(tofig2)  
for i in range(0,len(t9)):
    tit = str(t9[i])
    tofig2 = s9[i]
    sy900[i] = np.nanmean(tofig2)
for i in range(0,len(t1)):
    tit = str(t1[i])
    tofig2 = s1[i]
    sy1000[i] = np.nanmean(tofig2) 
  
#generate average phase synch for 800,900 and 1000 year moving window (for fig 10)
#given sun have different array dimension no artificial 0s exist. So no need to multiply by 2
    
for i in range(0,len(tt8)):
    tit = str(tt8[i])
    tofig3 = st8[i]
    sys800[i] = np.nanmean(tofig3)   
for i in range(0,len(tt9)):
    tit = str(tt9[i])
    tofig3 = st9[i]
    sys900[i] = np.nanmean(tofig3)
for i in range(0,len(tt1)):
    tit = str(tt1[i])
    tofig3 = st1[i]
    sys1000[i] = np.nanmean(tofig3) 
    
########################################################################################
#FIGURES for the 100 year bin#######

#Figure to color difference between sun-energy and human-energy in continents and total

#Calibrated dates
f00, ((ax1, ax2), (ax3,ax4),(ax5,ax6)) = plt.subplots(3,2, sharey=False, sharex=False, figsize=(10,15))
ax1.set_title ('Western U.S.A.',fontsize=20, color='black')
ax1.plot (time, dfcalib.usa, color ='black')
ax1.plot(time, dfcalib.sun, color ='red')  
ax1.fill_between(time, dfcalib.sun,dfcalib.usa, where=dfcalib.usa > dfcalib.sun, color ='grey', alpha='0.2')

ax2.set_title ('United Kingdom',fontsize=20, color='black')
ax2.plot (time, dfcalib.uk, color ='black')
ax2.plot(time, dfcalib.sun, color ='red')  
ax2.fill_between(time, dfcalib.sun,dfcalib.uk, where=dfcalib.uk > dfcalib.sun, color ='grey', alpha='0.2')

ax3.set_title ('Chile',fontsize=20, color='black')
ax3.plot (time, dfcalib.chile, color ='black')
ax3.plot(time, dfcalib.sun, color ='red')  
ax3.fill_between(time, dfcalib.sun,dfcalib.chile, where=dfcalib.chile>dfcalib.sun, color ='grey', alpha='0.2')

ax4.set_title ('Australia',fontsize=20, color='black')
ax4.plot (time, dfcalib.aus, color ='black')
ax4.plot(time, dfcalib.sun, color ='red')  
ax4.fill_between(time, dfcalib.sun,dfcalib.aus, where=dfcalib.aus>dfcalib.sun, color ='grey', alpha='0.2')

ax5.set_title ('All Sites',fontsize=20, color='black')
ax5.plot (time, tot, color ='black')
ax5.plot(time, dfcalib.sun, color ='red')  
ax5.fill_between(time, dfcalib.sun,tot, where=tot>dfcalib.sun, color ='grey', alpha='0.2')
f00.tight_layout()
f00.savefig('SocialAdvances_calib1.pdf', bbox_inches='tight')


#Figures showing synching between sun and human energy in areas and continets  btw the and with solar forcing
#for the whole 10,000 years
#note: En = south east england, while WA = north east england and wales.
labels = ('AZ','CA','CO','NM', 'NV','UT','WY','CHI','EN','WA','SC','IR','AU')
labels2 =('USA', 'UK', 'CHI', 'AUS')

f1, (ax1) = plt.subplots(1,1, sharey=False, sharex=False, figsize=(10,10))   
heat1 = sns.heatmap (phas, ax=ax1,cmap='Blues', vmin=0.8, vmax=1 ) 
ax1.set_title ('Average Synchronization',fontsize=20, color='black')
ax1.set_xticklabels(labels,fontsize=14, color='black')
ax1.set_yticklabels(labels, fontsize=14, color='black', rotation=0)
f1.tight_layout()
f1.savefig('Last10000_Area_Synch_calib1.pdf', bbox_inches='tight')  
    
f2, (ax1) = plt.subplots(1,1, sharey=False, sharex=False, figsize=(10,10))   
heat1 = sns.heatmap (regi, ax=ax1,cmap='Blues', vmin=0.8, vmax=1 ) 
ax1.set_title ('Average Synchronization',fontsize=20, color='black')
ax1.set_xticklabels(labels2,fontsize=14, color='black')
ax1.set_yticklabels(labels2, fontsize=14, color='black', rotation=0)
f2.tight_layout()
f2.savefig('Last10000_Region_Synch_calib1.pdf', bbox_inches='tight')  
    
f3, (ax1) = plt.subplots(1,1, sharey=False, sharex=False, figsize=(10,10))   
heat1 = sns.heatmap (tsun, ax=ax1,cmap='Blues', vmin=0.8, vmax=1 ) 
ax1.set_title ('Average Synchronization',fontsize=20, color='black')
ax1.set_xticklabels(labels,fontsize=14, color='black')
ax1.set_ylabel('Solar Forcing', fontsize=14, color='black')
f3.tight_layout()
f3.savefig('Last10000_Area_Sun_Synch_calib1.pdf', bbox_inches='tight')  

f4, (ax1) = plt.subplots(1,1, sharey=False, sharex=False, figsize=(10,10))   
heat1 = sns.heatmap (resun, ax=ax1,cmap='Blues', vmin=0.8, vmax=1 ) 
ax1.set_title ('Average Synchronization',fontsize=20, color='black')
ax1.set_xticklabels(labels2,fontsize=14, color='black')
ax1.set_ylabel('Solar Forcing', fontsize=20, color='black')
f4.tight_layout()
f4.savefig('Last10000_Region_Sun_Synch_calib1.pdf', bbox_inches='tight') 

#Figure synch moving windows for 800, 900 and 1000 years between different areas

f5, axs=plt.subplots(4,4, sharey=False, sharex=False, figsize=(20,20))  #this creates a new figure on which your plot will appear
axs = axs.ravel()
for i in range(0,len(t8)):
    tit = str(t8[i])
    tofig = s8[i]
    tofig[tofig == 0] = 'nan' 
    n = str(i+1)
    sns.heatmap(tofig, cmap='Blues', ax=axs[i], vmin=0.5, vmax=1)
    axs[i].set_title (tit,fontsize=20, color='black')
    axs[i].set_xticklabels(labels,fontsize=14, color='black')
    axs[i].set_yticklabels(labels,fontsize=14, color='black', rotation=0)
f5.tight_layout()
f5.savefig('WorldSeparate_800_calib1.pdf', bbox_inches='tight')

f6, axs=plt.subplots(4,3, sharey=False, sharex=False, figsize=(20,20))  #this creates a new figure on which your plot will appear
axs = axs.ravel()
for i in range(0,len(t9)):
    tit = str(t9[i])
    tofig = s9[i]
    tofig[tofig == 0] = 'nan' 
    n = str(i+1)
    sns.heatmap(tofig, cmap='Blues', ax=axs[i], vmin=0.5, vmax=1)
    axs[i].set_title (tit,fontsize=20, color='black')
    axs[i].set_xticklabels(labels,fontsize=14, color='black')
    axs[i].set_yticklabels(labels,fontsize=14, color='black', rotation=0)
f6.tight_layout()
f6.savefig('WorldSeparate_900_calib1.pdf', bbox_inches='tight')

#Figure synch 1000 years between different areas
f7, axs=plt.subplots(4,3, sharey=False, sharex=False, figsize=(20,20))  #this creates a new figure on which your plot will appear
axs = axs.ravel()
for i in range(0,len(t1)):
    tit = str(t1[i])
    tofig = s1[i]
    tofig[tofig == 0] = 'nan' 
    n = str(i+1)
    sns.heatmap(tofig, cmap='Blues', ax=axs[i],vmin=0.5, vmax=1)
    axs[i].set_title (tit,fontsize=20, color='black')
    axs[i].set_xticklabels(labels,fontsize=14, color='black')
    axs[i].set_yticklabels(labels,fontsize=14, color='black', rotation = 0)
f7.tight_layout()
f7.savefig('WorldSeparate_1000_calib1.pdf', bbox_inches='tight')


#figure to plot avg synch values
f8, (ax1,ax2,ax3) = plt.subplots(3,1, sharey=False, sharex=False, figsize=(5,15))   
ax1.plot(t8,sy800, color='Black')
ax1.set_title('800 Year Intervals', fontsize=24, color='black')
ax1.set_ylabel('Avg Synch', fontsize=20, color='black')
ax1.set_xlabel('Time Before Present', fontsize=20, color='black')

ax2.plot(t9,sy900, color='Black')
ax2.set_title('900 Year Intervals', fontsize=24, color='black')
ax2.set_ylabel('Avg Synch', fontsize=20, color='black')
ax2.set_xlabel('Time Before Present', fontsize=20, color='black')

ax3.plot(t1,sy1000, color='Black')
ax3.set_title('1000 Year Intervals', fontsize=24, color='black')
ax3.set_ylabel('Avg Synch', fontsize=20, color='black')
ax3.set_xlabel('Time Before Present', fontsize=20, color='black')
f8.tight_layout()
f8.savefig('AvgSynch_BTW_Zones_calib1.pdf', bbox_inches='tight')  


f9, (ax1,ax2,ax3) = plt.subplots(1,3, sharey=False, sharex=False, figsize=(20,5)) 
heat1 = sns.heatmap (syt800, ax=ax1,cmap='Blues', vmin=0.2, vmax=1 ) 
ax1.set_title ('800 Years',fontsize=20, color='black')
ax1.set_xticklabels(labels,fontsize=14, color='black')
ax1.set_yticklabels(tt8, fontsize=14, color='black', rotation=0)

heat2 = sns.heatmap (syt900, ax=ax2,cmap='Blues', vmin=0.2, vmax=1 ) 
ax2.set_title ('900 Years',fontsize=20, color='black')
ax2.set_xticklabels(labels,fontsize=14, color='black')
ax2.set_yticklabels(tt9, fontsize=14, color='black', rotation=0)

heat3 = sns.heatmap (syt1000, ax=ax3,cmap='Blues', vmin=0, vmax=1 ) 
ax3.set_title ('1000 Years',fontsize=20, color='black')
ax3.set_xticklabels(labels,fontsize=14, color='black')
ax3.set_yticklabels(tt1, fontsize=14, color='black', rotation=0)
f9.tight_layout()
f9.savefig('SunEnergy_Energy_Synch_calib1.pdf', bbox_inches='tight')


f10, (ax1,ax2,ax3) = plt.subplots(3,1, sharey=False, sharex=False, figsize=(5,15))   
ax1.plot(tt8,sys800, color='Black')
ax1.set_title('800 Year Intervals', fontsize=24, color='black')
ax1.set_ylabel('Avg Synch', fontsize=20, color='black')
ax1.set_xlabel('Time Before Present', fontsize=20, color='black')

ax2.plot(tt9,sys900, color='Black')
ax2.set_title('900 Year Intervals', fontsize=24, color='black')
ax2.set_ylabel('Avg Synch', fontsize=20, color='black')
ax2.set_xlabel('Time Before Present', fontsize=20, color='black')

ax3.plot(tt1,sys1000, color='Black')
ax3.set_title('1000 Year Intervals', fontsize=24, color='black')
ax3.set_ylabel('Avg Synch', fontsize=20, color='black')
ax3.set_xlabel('Time Before Present', fontsize=20, color='black')

f10.tight_layout()
f10.savefig('AvgSynch_Sun_Zones_calib1.pdf', bbox_inches='tight') 
