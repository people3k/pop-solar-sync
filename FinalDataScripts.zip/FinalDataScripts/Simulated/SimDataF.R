###Mutual Information on Simulated Data
library(muti)
##This file is for the creation and analysis of similated radiocarbon dates. Note that standard errors are
#entered mannually in a spreadsheet to change the standard error values for calibration.

#####Create Random samples of radiocarbon dates from a randomly fluctuating uniform distribution
#of 1 million dates This creates a 100 radiocarbon time-series

set.seed(1234)
RCDPop<-runif(1000000, min=0, max=11000 )
RCDSamp <- replicate(100, sample(RCDPop,1500, replace=TRUE))

##Sort the data from oldest to youngest age.
CD.sorted <- apply(RCDSamp,2,sort,decreasing=F)
write.table(CD.sorted, file = "SimTest.csv", sep = ",")


###Binning Raw Dates by frequency. This code bins the ``raw dates" by fr3equency.
#One can run mutual information on these simulated raw dates binned by frequency and 
#you will find that less than 5% of sequences display significant mutual information

CD.sorted <- read.csv("SimRCD.csv", header=T)
x=CD.sorted[, 3:102]
mycut=function(x)  table(cut(x, breaks=22))
xbin=apply(x,2,mycut)
write.table(xbin, file = "Raw/Bin500.csv", sep = ",")

x<-CD.sorted$Time
y1<-(CD.sorted$V1)
y2<-(CD.sorted$V2)


#########SPD of Simulated RCD sequences. Create multiple files with different standard errors and 
#calibrate and create an SPD for each sequence. This code will create an individual file for 
#each simulated time-series
library(rcarbon)
library(stats)
#set working directory to file location
Rawdata <- read.csv("SimRCD.csv", header=T)

###3Calibrate and Run SPDs  
for(i in 3:102){
  bins <- binPrep(sites=Rawdata$SiteID, ages=Rawdata[[i]], h=0)
  x <- calibrate(x=Rawdata[[i]], errors=Rawdata$Error, normalised=FALSE)
  spd.CO <- spd(x, bins=bins, runm=NA, timeRange=c(10400,400))
  write.table(spd.CO, file = paste("SPD_V", (i-2), ".csv", sep = ""), sep = ",")
}

###SPD of Simulated RCD sequences, 50 year SDs
Rawdata <- read.csv("SimRCD2.csv", header=T)

###3Calibrate and Run SPDs  
for(i in 3:102){
  bins <- binPrep(sites=Rawdata$SiteID, ages=Rawdata[[i]], h=0)
  x <- calibrate(x=Rawdata[[i]], errors=Rawdata$Error, normalised=FALSE)
  spd.CO <- spd(x, bins=bins, runm=NA, timeRange=c(10400,400))
  write.table(spd.CO, file = paste("SD50/SPD_V", (i-2), ".csv", sep = ""), sep = ",")
}

###SPD of Simulated RCD sequences, 100 year SDs
Rawdata <- read.csv("SimRCD3.csv", header=T)

###3Calibrate and Run SPDs  
for(i in 3:102){
  bins <- binPrep(sites=Rawdata$SiteID, ages=Rawdata[[i]], h=0)
  x <- calibrate(x=Rawdata[[i]], errors=Rawdata$Error, normalised=FALSE)
  spd.CO <- spd(x, bins=bins, runm=NA, timeRange=c(10400,400))
  write.table(spd.CO, file = paste("SD100/SPD_V", (i-2), ".csv", sep = ""), sep = ",")
}


#Aggregate (sum) into bins, set working directory to file folder with SPDS for each sampled sequence

temp <- list.files(pattern="*.csv")
list2env(
  lapply(setNames(temp, make.names(gsub("*.csv$", "", temp))), 
         read.csv), envir = .GlobalEnv)

files <- list.files(path="./")
genes <- read.table(files[1], header=TRUE, sep=",")[,10]     # gene names
df    <- do.call(cbind,lapply(files,function(fn)read.table(fn,header=TRUE, sep=",")[,11]))
df2    <- cbind(genes,df)
write.table(df2, file = "SimSPD100.csv", sep = ",")


###Sum the spd data at different bin widths
library(zoo)
keep <- read.csv("SimSPD100.csv", header=T)


out10 <- rollapply(keep,10,(sum),by=10,by.column=TRUE,align='right')
write.table(out10, file = "Sum10.csv", sep = ",")

out20 <- rollapply(keep,20,(sum),by=20,by.column=TRUE,align='right')
write.table(out20, file = "Sum20.csv", sep = ",")

out50 <- rollapply(keep,50,(sum),by=50,by.column=TRUE,align='right')
write.table(out50, file = "Sum50.csv", sep = ",")

out100 <- rollapply(keep,100,(sum),by=100,by.column=TRUE,align='right')
write.table(out100, file = "Sum100.csv", sep = ",") 

out30<- rollapply(keep,30,(sum),by=30,by.column=TRUE,align='right')
write.table(out30, file = "Sum30.csv", sep = ",") 

out500<-rollapply(keep,500,(sum),by=500,by.column=TRUE,align='right')
write.table(out500, file = "Sum500.csv", sep = ",") 

##If you would like to add solar energy to the sequences, you will need to add this mannually
#in a spreadsheet or do so by joing in r.

####Run mutual information on every two columns to run calibrated spds against solar energy
library(muti)
bin100 <- read.csv("Sum500_f.csv", header=T)

dzCasesYears = list() #Prep a list to store your results
counter = 0 # To store your corr.test into list through iterating

for (i in 1:101)
{
  counter = counter + 1
  # Creating new variables makes the code clearer
  x = (bin100$sun)
  y = (bin100[[i]])
  
  dzCasesYears[[counter]] <-muti(x, y, sym = TRUE, mc=100, alpha=.05, lags=seq(-3,3))
}

#Save the mutual information and significance data for analysis. Be sure to change your file names
#to keep your bins straight.

binten2<-as.matrix(dzCasesYears)
write.table(binten2, file = "SunM500_fSig.csv", sep = ",")
write.table(dzCasesYears, file = "Sun500_fSig.csv", sep = ",")

#########All pairwis emutual informations
##You
bin10 <- read.csv("SD100/Sum50_f.csv", header=T)

election <- as.data.frame(bin10)
binone = list() #Prep a list to store your corr.test results
counter = 0 # To store your corr.test into list through iterating

for (i in 1:ncol(election)) {
  for (j in 1:ncol(election)) {
    counter = counter +1
    binone[[counter]]<-muti(bin10[,i], bin10[,j], sym = TRUE, mc=100, alpha=.05, lags=seq(0,0))
  }
  
} 
###Convert list to matrix and save
binten2<-as.matrix(binone)
write.table(binten2, file = "SD100/Bin50SigTotal.csv", sep = ",")


