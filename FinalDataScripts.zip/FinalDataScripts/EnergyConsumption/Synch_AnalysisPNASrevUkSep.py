#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 20 15:06:32 2018

This script is used, together with synchfunctions, to generate the figures for Freeman, Baggio, Robinson et al. "Global Synchrony of human population and solar energy throughout the Holocene"

This script allows for the synch analysis of human energy and solar energy between 10400 and 400 years ago. 

The script uses both, calibrated summed probability distribution data (spdcalib) and raw radiocarbon dates.
Calibrated data are Raw dates calibrated on a highly non-linear curve derived from tree rings and that partially accounts
for solar forcing.

This script analyzses mutual information (or synchronization) between t-series representing energy consumption in different
areas of the world binned at 10, 20, 30, 50, 100, 500 and 1000 years. 

This script provide the final analysis used in 
Freeman, Baggio, Robinson et al. "Global Synchrony of human population and solar energy throughout the Holocene"


@author: Jacopo A. Baggio, 
Department of Political Science and National Center for Integrated Coastal Research, 
University of Central Florida

"""

#General python packages
import seaborn as sns
import matplotlib.pyplot as plt
import os
import glob
import pandas as pd
import numpy as np
import scipy as sp

#Functions for calculating symbolic time-series, mutual information, phase locking value, significance of mutual information
#based of markov chain of order 1 are in the following "functions file".
import synchfunctions as sfu

"""
Where files (csv) are kept. This is a local path, if you want to reproduce the analysis, the path needs to change to where
you have saved the datafiles. Note that you will need two file-paths, one for the raw dates one for the calibrated ones.
Having two file paths is better as names of the variables are slightly different and the calibrated dates include solar forcing
"""


wfilecalib = ('/Users/jacopo/Documents/A_STUDI/AAA_work/CoupledInfra_LongTermVariance/HumanSyncing/PNASData/Calib2')


#move to a working directory for output. 
wdir =('/Users/jacopo/Documents/A_STUDI/AAA_work/CoupledInfra_LongTermVariance/HumanSyncing/PNASFigs/Uksep/FinalMain')

wdir2 =('/Users/jacopo/Documents/A_STUDI/AAA_work/CoupledInfra_LongTermVariance/HumanSyncing/PNASFigs/Uksep/FinalSuppl')


#load all dataframes with specific names
#get the files in the dataframe 

    
dfscalib={}
os.chdir(wfilecalib)
for filename in glob.glob('*.csv'):
    name = int(filename[6:-4])
    print (filename)
    #load data
    dfscalib[name]= pd.read_csv(filename)
    
"""
Start first analysis, using Symbolic Time-Series

Use method proposed by Cazelles, B., 2004. 
Symbolic dynamics for identifying similarity between rhythms of ecological time series. 
Ecol. Lett. 7, 755–763. doi:10.1111/j.1461-0248.2004.00629.x 
To assess synchronization

STEP 1: define the rithm of time series by transforming it in a series of "symbols". Symbols represent either 
 peak, through point, increase or decrease in a time-series (symbols used at the end) - also used in 
Haydon, D.T., Greenwood, P.E., Stenseth, N.C. & Saitoh, T. (2003). Spatio-temporal dynamics of the grey-sided vole in Hokkaido: 
Identifying coupling using state-based Markov-chain modelling. Proc. R. Soc. Lond. B, 270, 435–445.

STEP 2: Caluclate Mutual Information in Bits (sfu.mutual) for areas

Step 3: assess significance of mutual information
The process invovles creating Markov Chain of order 1 surrogate time-series.
The number of surrogate time series depends on the value of the parameter "reps"
Using Markov Chains of order 1 allows to recreate time-series maintaining local structure of the original t-s.
"""


#setup dictionaries to record results for both raw and calibrate dates
calibfigs = {}


#Go and do analysis for calibrated dates. 
os.chdir (wfilecalib)
sequence1 = ['ariz', 'cali','colo','nmex','neva', 'utah', 'wyom','seuk', 	'nwuk','ire','scot','aus','chile','sun',]

for filename in glob.glob('*.csv'):
    name = int(filename[6:-4])
    print (filename)
    #load data
    dfdata = pd.read_csv(filename)
    
    #transform time-series in symbolic 
    haz  = sfu.symbtransf(dfdata.ariz)
    hca  = sfu.symbtransf(dfdata.cali)
    hco  = sfu.symbtransf(dfdata.colo)
    hnm  = sfu.symbtransf(dfdata.nmex)
    hnv  = sfu.symbtransf(dfdata.neva)
    hut  = sfu.symbtransf(dfdata.utah)
    hwy  = sfu.symbtransf(dfdata.wyom)
    hau  = sfu.symbtransf(dfdata.aus)
    hse  = sfu.symbtransf(dfdata.seuk)
    hnw  = sfu.symbtransf(dfdata.nwuk)
    hir  = sfu.symbtransf(dfdata.ire)
    hsc  = sfu.symbtransf(dfdata.scot)
    hch  = sfu.symbtransf(dfdata.chile)
    hsun  = sfu.symbtransf(dfdata.sun)

    #create new object, dataframe, where to store all the symbolic time-series
    dfsymbarea= pd.DataFrame({'sun': hsun, 'aus': hau, 'chile': hch, 'seuk': hse, 'nwuk':hnw, 'ire':hir, 'scot':hsc, 'ariz': haz, 'cali':hca,'colo': hco,'nmex': hnm,'neva': hnv, 'utah': hut,'wyom': hwy})
    
    #change sequence of columns, for figure purposes looks better. First western USA, than USA, then other continents, finally solar forcing.
    dfsymbarea = dfsymbarea.reindex(columns=sequence1)
    
    #create empty array to store results
    phasarea= np.zeros((14,14))
    
    #Step 2 Caluclate Mutual Information in Bits (sfu.mutual) for areas and for continents
    for i in range (0, np.size(dfsymbarea,1)):
        for j in range (0, np.size(dfsymbarea,1)):
            x1 = list(dfsymbarea.iloc[:,i])
            x2 = list(dfsymbarea.iloc[:,j])
            phasarea[i,j] = sfu.mutual(x1,x2)

    #as of now, there is a problem as same (3) is not present, but 3 = e in symbolic letters, 
    #and so there is no space between integers. This is important to allow the markov chain code to work.    
    haz  = sfu.symbtransflet(dfdata.ariz)
    hca  = sfu.symbtransflet(dfdata.cali)
    hco  = sfu.symbtransflet(dfdata.colo)
    hnm  = sfu.symbtransflet(dfdata.nmex)
    hnv  = sfu.symbtransflet(dfdata.neva)
    hut  = sfu.symbtransflet(dfdata.utah)
    hwy  = sfu.symbtransflet(dfdata.wyom)
    hau  = sfu.symbtransflet(dfdata.aus)
    hse  = sfu.symbtransflet(dfdata.seuk)
    hnw  = sfu.symbtransflet(dfdata.nwuk)
    hir  = sfu.symbtransflet(dfdata.ire)
    hsc  = sfu.symbtransflet(dfdata.scot)
    hch  = sfu.symbtransflet(dfdata.chile)
    hsun  = sfu.symbtransflet(dfdata.sun)

    dfsigarea = pd.DataFrame({'sun': hsun, 'aus': hau, 'chile': hch, 'seuk': hse, 'nwuk':hnw, 'ire':hir, 'scot':hsc, 'ariz': haz, 'cali':hca,'colo': hco,'nmex': hnm,'neva': hnv, 'utah': hut,'wyom': hwy})
    #change sequence of columns, for figure purposes looks better. First western USA, than USA, then other continents, finally solar forcing.
    dfsigarea = dfsigarea.reindex(columns=sequence1)

    #significance value are almost-symmetrical, however, for easier coding, we leave the entrire results. 
    #The non-symmetry of the results even after 1000 repetition is a result of the stochasticity 
    #inbuild the markov-chain of order 1 process or for the montecarlo (aka markov chain order 0)
    reps = 500
    sigarea = np.zeros((reps,14,14))

    for r in range (0,reps):
        for i in range (0, np.size(dfsigarea,1)):
            for j in range (0, np.size(dfsigarea,1)): 
                x1 = sfu.markc(dfsigarea.iloc[:,i],0)
                x2 = sfu.markc(dfsigarea.iloc[:,j],0)
                sigarea[r,i,j] = sfu.mutual(x1,x2)
   
    #create matrix to contain the significance value (if above = significant) of the surrogate 
    #time-series mutual info for areas
    sig95area = np.zeros((14,14))
    for i in range (0, np.size(dfsymbarea,1)):
        for j in range (0, np.size(dfsymbarea,1)):
            mu, sigma = np.mean(sigarea[:,i,j]), np.std(sigarea[:,i,j])
            sig95area[i][j] = sp.stats.norm.interval(0.95, loc=mu, scale=sigma)[1]
    

    ptri = np.tril(phasarea, k=-1)
    ptri[ptri == 0] = np.nan
    
    stri = np.tril(sig95area, k=-1) #use only mutual info, and not entropy to calculate avg mutual info
    stri[stri==0] = np.nan
    
    ptridiag = np.tril(phasarea, k=0)
    ptridiag[ptridiag == 0] = np.nan
    
    sigperc = sum(sum(i >= 0 for i in (ptri-stri))) / 91 # as 91 = number of entries in the matrix, gives an idea of % significant
    avgmi = np.nanmean (ptri) #average mutual information
    
    #create dictionary and update master dictionary
    calibfig1= {str(name)+'symb':dfsymbarea, str(name)+'mi':ptridiag, str(name)+'sig':sigarea, str(name)+'95':sig95area, str(name)+'avgMI':avgmi , str(name)+'sigperc':sigperc}
    calibfigs.update(calibfig1)



#Figures for Paper
            
    
#labels for symbolic figures. 
symblab = ['Through','Decrease', 'Same','Increase','Peak']

#labels for areas
rlabels = ('AZ','CA','CO','NM', 'NV','UT','WY','SE','NW', 'IR', 'SC', 'AU','CHI')
clabels = ('AZ','CA','CO','NM', 'NV','UT','WY','SE','NW', 'IR', 'SC','AU','CHI','SUN')

#set seaborn context
sns.set(context='paper', style='white', palette='colorblind', font_scale=1)
#create colorbar so it is only one for the figure
im = plt.imshow(np.random.random((14,14)), vmin=0, vmax=1, cmap='Blues')       


if not os.path.exists(wdir):
    os.makedirs(wdir)
os.chdir(wdir)


#Heatmap for mutual information at different binning intervals for raw dates


f11,((ax1,ax2,ax3),(ax4,ax5,ax6)) = plt.subplots(2,3, sharey=False, sharex=False,  figsize=(20,20))
cbar_ax = f11.add_axes([1.01, 0.25, 0.025, 0.5])
    
heat1 = sns.heatmap (calibfigs['10mi'], annot=True, fmt='.3f', ax=ax1,cmap='Blues',square = True, vmin=0, vmax=1,cbar=False ) 
ax1.set_title ('Calibrated Dates Binned at 10 Years',fontsize=20, color='black')
ax1.set_xticklabels(clabels,fontsize=16, color='black')
ax1.set_yticklabels(clabels, fontsize=16, color='black', rotation=0)

heat2 = sns.heatmap (calibfigs['20mi'], annot=True, fmt='.3f', ax=ax2,cmap='Blues',square = True, vmin=0, vmax=1,cbar=False ) 
ax2.set_title ('Calibrated Dates Binned at 20 Years',fontsize=20, color='black')
ax2.set_xticklabels(clabels,fontsize=16, color='black')
ax2.set_yticklabels(clabels, fontsize=16, color='black', rotation=0)
 
heat3 = sns.heatmap (calibfigs['30mi'], annot=True, fmt='.3f', ax=ax3,cmap='Blues',square = True, vmin=0, vmax=1,cbar=False ) 
ax3.set_title ('Calibrated Dates Binned at 30 Years',fontsize=20, color='black')
ax3.set_xticklabels(clabels,fontsize=16, color='black')
ax3.set_yticklabels(clabels, fontsize=16, color='black', rotation=0)
    
heat4 = sns.heatmap (calibfigs['50mi'], annot=True, fmt='.3f', ax=ax4,cmap='Blues',square = True, vmin=0, vmax=1,cbar=False ) 
ax4.set_title ('Calibrated Dates Binned at 50 Years',fontsize=20, color='black')
ax4.set_xticklabels(clabels,fontsize=16, color='black')
ax4.set_yticklabels(clabels, fontsize=16, color='black', rotation=0)
    
heat5 = sns.heatmap (calibfigs['100mi'], annot=True, fmt='.3f', ax=ax5,cmap='Blues',square = True, vmin=0, vmax=1,cbar=False ) 
ax5.set_title ('Calibrated Dates Binned at 100 Years',fontsize=20, color='black')
ax5.set_xticklabels(clabels,fontsize=16, color='black')
ax5.set_yticklabels(clabels, fontsize=16, color='black', rotation=0)
    
heat6 = sns.heatmap (calibfigs['500mi'], annot=True, fmt='.3f', ax=ax6,cmap='Blues',square = True, vmin=0, vmax=1,cbar=False ) 
ax6.set_title ('Calibrated Dates Binned at 500 Years',fontsize=20, color='black')
ax6.set_xticklabels(clabels,fontsize=16, color='black')
ax6.set_yticklabels(clabels, fontsize=16, color='black', rotation=0)
 
f11.colorbar(im, cax=cbar_ax)
f11.tight_layout()
f11.savefig('Calib_Main_MI_Area.pdf', bbox_inches='tight')  
            
#Prepare dataset and data for Bar Graph summaries

binlabel = ['10 Year Bins', '20 Year Bins', '30 Year Bins', '50 Year Bins', '100 Year Bins', '500 Year Bins']

calibbarmi = [calibfigs['10avgMI'],calibfigs['20avgMI'],calibfigs['30avgMI'],calibfigs['50avgMI'],calibfigs['100avgMI'],calibfigs['500avgMI']]
calibbarsig = [calibfigs['10sigperc'],calibfigs['20sigperc'],calibfigs['30sigperc'],calibfigs['50sigperc'],calibfigs['100sigperc'],calibfigs['500sigperc']]

f12, (ax1,ax2) = plt.subplots(2,1, sharey=False, sharex=False,  figsize=(30,20))

ax1.bar(binlabel, calibbarmi, width=0.9)
ax1.set_title ('Calibrated Dates Average Mutual Information', fontsize=32, color ='black')
ax1.set_xticklabels (binlabel, fontsize=26, color ='black', rotation=45)
ax1.set_ylabel ('Avg Mutual Information', fontsize=32, color ='black')
ax1.tick_params(axis='y',labelsize = 26)

ax2.bar(binlabel, calibbarsig, width=0.9)
ax2.set_title ('Calibrated Dates Significance', fontsize=32, color ='black')
ax2.set_xticklabels (binlabel, fontsize=26, color ='black', rotation=45)
ax2.set_ylabel ('% Significance', fontsize=32, color ='black')
ax2.tick_params(axis='y',labelsize = 26)

f12.tight_layout()
f12.savefig('AvgMI_Sig.pdf', bbox_inches='tight')  
 


if not os.path.exists(wdir2):
    os.makedirs(wdir2)
os.chdir(wdir2)


#Significance for Areas with Calibrated Dates at different binning intervals.

f22, axs = plt.subplots(14,14, sharey=False, sharex=False,  figsize=(40,40))
axs.ravel()
for i in range(0,14):
    for j in range (0,14):
        if i<=j:
            axs[i,j].axis('off')
        else:
            axs[i,j].hist(calibfigs['10sig'][:,i,j])
            axs[i,j].set_title(clabels[i] + '-' + clabels[j] + ' ' + 'Significance', fontsize=18, color='black')
            axs[i,j].axvline(x = calibfigs['10mi'][i,j],color= 'r')
            axs[i,j].axvline(x = calibfigs['1095'][i,j], color= 'b', linestyle='--')
fig=axs[0,0].figure
fig.text(0.5,-0.01, 'MI between Calibrated Surrogate Time-Series', ha='center', va='center', fontsize=30 )
fig.text(-0.01,0.5, 'Frequency of MI in Calibrated Surrogate Time-Series', ha='center', va='center', rotation=90, fontsize=30)

f22.tight_layout()
f22.savefig('CalibratedSignificance_MI_10.pdf', bbox_inches='tight')  


f23, axs = plt.subplots(14,14, sharey=False, sharex=False,  figsize=(40,40))
axs.ravel()
for i in range(0,14):
    for j in range (0,14):
        if i<=j:
            axs[i,j].axis('off')
        else:
            axs[i,j].hist(calibfigs['20sig'][:,i,j])
            axs[i,j].set_title(clabels[i] + '-' + clabels[j] + ' ' + 'Significance', fontsize=18, color='black')
            axs[i,j].axvline(x = calibfigs['20mi'][i,j],color= 'r')
            axs[i,j].axvline(x = calibfigs['2095'][i,j], color= 'b', linestyle='--')
fig=axs[0,0].figure
fig.text(0.5,-0.01, 'MI between Calibrated Surrogate Time-Series', ha='center', va='center', fontsize=30 )
fig.text(-0.01,0.5, 'Frequency of MI in Calibrated Surrogate Time-Series', ha='center', va='center', rotation=90, fontsize=30)

f23.tight_layout()
f23.savefig('CalibratedSignificance_MI_20.pdf', bbox_inches='tight')  


f24, axs = plt.subplots(14,14, sharey=False, sharex=False,  figsize=(40,40))
axs.ravel()
for i in range(0,14):
    for j in range (0,14):
        if i<=j:
            axs[i,j].axis('off')
        else:
            axs[i,j].hist(calibfigs['30sig'][:,i,j])
            axs[i,j].set_title(clabels[i] + '-' + clabels[j] + ' ' + 'Significance', fontsize=18, color='black')
            axs[i,j].axvline(x = calibfigs['30mi'][i,j],color= 'r')
            axs[i,j].axvline(x = calibfigs['3095'][i,j], color= 'b', linestyle='--')
fig=axs[0,0].figure
fig.text(0.5,-0.01, 'MI between Calibrated Surrogate Time-Series', ha='center', va='center', fontsize=30 )
fig.text(-0.01,0.5, 'Frequency of MI in Calibrated Surrogate Time-Series', ha='center', va='center', rotation=90, fontsize=30)

f24.tight_layout()
f24.savefig('CalibratedSignificance_MI_30.pdf', bbox_inches='tight')  


f25, axs = plt.subplots(14,14, sharey=False, sharex=False,  figsize=(40,40))
axs.ravel()
for i in range(0,14):
    for j in range (0,14):
        if i<=j:
            axs[i,j].axis('off')
        else:
            axs[i,j].hist(calibfigs['50sig'][:,i,j])
            axs[i,j].set_title(clabels[i] + '-' + clabels[j] + ' ' + 'Significance', fontsize=18, color='black')
            axs[i,j].axvline(x = calibfigs['50mi'][i,j],color= 'r')
            axs[i,j].axvline(x = calibfigs['5095'][i,j], color= 'b', linestyle='--')
fig=axs[0,0].figure
fig.text(0.5,-0.01, 'MI between Calibrated Surrogate Time-Series', ha='center', va='center', fontsize=30 )
fig.text(-0.01,0.5, 'Frequency of MI in Calibrated Surrogate Time-Series', ha='center', va='center', rotation=90, fontsize=30)

f25.tight_layout()
f25.savefig('CalibratedSignificance_MI_50.pdf', bbox_inches='tight')  


f26, axs = plt.subplots(14,14, sharey=False, sharex=False,  figsize=(40,40))
axs.ravel()
for i in range(0,14):
    for j in range (0,14):
        if i<=j:
            axs[i,j].axis('off')
        else:
            axs[i,j].hist(calibfigs['100sig'][:,i,j])
            axs[i,j].set_title(clabels[i] + '-' + clabels[j] + ' ' + 'Significance', fontsize=18, color='black')
            axs[i,j].axvline(x = calibfigs['100mi'][i,j],color= 'r')
            axs[i,j].axvline(x = calibfigs['10095'][i,j], color= 'b', linestyle='--')
fig=axs[0,0].figure
fig.text(0.5,-0.01, 'MI between Calibrated Surrogate Time-Series', ha='center', va='center', fontsize=30 )
fig.text(-0.01,0.5, 'Frequency of MI Calibrated in Surrogate Time-Series', ha='center', va='center', rotation=90, fontsize=30)

f26.tight_layout()
f26.savefig('CalibratedSignificance_MI_100.pdf', bbox_inches='tight')  


f27, axs = plt.subplots(14,14, sharey=False, sharex=False,  figsize=(40,40))
axs.ravel()
for i in range(0,14):
    for j in range (0,14):
        if i<=j:
            axs[i,j].axis('off')
        else:
            axs[i,j].hist(calibfigs['500sig'][:,i,j])
            axs[i,j].set_title(clabels[i] + '-' + clabels[j] + ' ' + 'Significance', fontsize=18, color='black')
            axs[i,j].axvline(x = calibfigs['500mi'][i,j],color= 'r')
            axs[i,j].axvline(x = calibfigs['50095'][i,j], color= 'b', linestyle='--')
fig=axs[0,0].figure
fig.text(0.5,-0.01, 'MI between Calibrated Surrogate Time-Series', ha='center', va='center', fontsize=30 )
fig.text(-0.01,0.5, 'Frequency of MI in Calibrated Surrogate Time-Series', ha='center', va='center', rotation=90, fontsize=30)

f27.tight_layout()
f27.savefig('CalibratedSignificance_MI_500.pdf', bbox_inches='tight')  


### Per Area, original vs symbolic transformation at different bins

#####################SAME FOR CALIBRATED DATES

#Arizona
f40, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].ariz)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].ariz, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].ariz)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].ariz, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].ariz)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].ariz, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].ariz)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].ariz, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].ariz)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].ariz, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].ariz)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].ariz, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)



ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f40.tight_layout()
f40.savefig('Calib_Arizona_OrigSymb.pdf', bbox_inches='tight')


#California

f41, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].cali)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].cali, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].cali)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].cali, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].cali)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].cali, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].cali)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].cali, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].cali)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].cali, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].cali)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].cali, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)


ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f41.tight_layout()
f41.savefig('Calib_California_OrigSymb.pdf', bbox_inches='tight')

#Colorado

f42, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].colo)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].colo, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].colo)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].colo, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].colo)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].colo, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].colo)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].colo, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].colo)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].colo, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].colo)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].colo, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f42.tight_layout()
f42.savefig('Calib_Colorado_OrigSymb.pdf', bbox_inches='tight')


#Nevada

f43, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].neva)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].neva, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].neva)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].neva, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].neva)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].neva, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].neva)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].neva, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].neva)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].neva, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].neva)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].neva, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f43.tight_layout()
f43.savefig('Calib_Nevada_OrigSymb.pdf', bbox_inches='tight')

#New Mexico

f44, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].nmex)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].nmex, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].nmex)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].nmex, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].nmex)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].nmex, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].nmex)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].nmex, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].nmex)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].nmex, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].nmex)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].nmex, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f44.tight_layout()
f44.savefig('Calib_NewMexico_OrigSymb.pdf', bbox_inches='tight')

#Utah

f45, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].utah)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].utah, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].utah)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].utah, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].utah)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].utah, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].utah)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].utah, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].utah)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].utah, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].utah)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].utah, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f45.tight_layout()
f45.savefig('Calib_Utah_OrigSymb.pdf', bbox_inches='tight')

#Wyoming
f46, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].wyom)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].wyom, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].wyom)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].wyom, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].wyom)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].wyom, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].wyom)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].wyom, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].wyom)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].wyom, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].wyom)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].wyom, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f46.tight_layout()
f46.savefig('Calib_Wyoming_OrigSymb.pdf', bbox_inches='tight')

#Australia

f47, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].aus)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].aus, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].aus)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].aus, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].aus)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].aus, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].aus)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].aus, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].aus)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].aus, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].aus)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].aus, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f47.tight_layout()
f47.savefig('Calib_Australia_OrigSymb.pdf', bbox_inches='tight')


#South-East UK
f48, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].seuk)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].seuk, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].seuk)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].seuk, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].seuk)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].seuk, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].seuk)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].seuk, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].seuk)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].seuk, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].seuk)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].seuk, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f48.tight_layout()
f48.savefig('Calib_SE_UK_OrigSymb.pdf', bbox_inches='tight')


#North-West UK
f49, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].nwuk)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].nwuk, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].nwuk)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].nwuk, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].nwuk)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].nwuk, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].nwuk)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].nwuk, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].nwuk)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].nwuk, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].nwuk)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].nwuk, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f49.tight_layout()
f49.savefig('Calib_MW_UK_OrigSymb.pdf', bbox_inches='tight')


#Ireland

f50, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].ire)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].ire, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].ire)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].ire, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].ire)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].ire, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].ire)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].ire, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].ire)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].ire, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].ire)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].ire, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f50.tight_layout()
f50.savefig('Calib_IRE_OrigSymb.pdf', bbox_inches='tight')

#Scotland
f51, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].sco)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].sco, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].sco)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].sco, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].sco)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].sco, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].sco)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].sco, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].sco)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].sco, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].sco)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].sco, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f51.tight_layout()
f51.savefig('Calib_IRE_OrigSymb.pdf', bbox_inches='tight')



#Chile
f52, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].chile)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].chile, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].chile)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].chile, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].chile)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].chile, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].chile)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].chile, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].chile)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].chile, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].chile)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].chile, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f52.tight_layout()
f52.savefig('Calib_Chile_OrigSymb.pdf', bbox_inches='tight')


#sun
f53, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12)) = plt.subplots(6,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfscalib[10].bp,dfscalib[10].sun)
ax1.invert_xaxis()
ax2.plot(calibfigs['10symb'].sun, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfscalib[20].bp,dfscalib[20].sun)
ax3.invert_xaxis()
ax4.plot(calibfigs['20symb'].sun, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax5.plot(dfscalib[30].bp,dfscalib[30].sun)
ax5.invert_xaxis()
ax6.plot(calibfigs['30symb'].sun, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfscalib[50].bp,dfscalib[50].sun)
ax7.invert_xaxis()
ax8.plot(calibfigs['50symb'].sun, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfscalib[100].bp,dfscalib[100].sun)
ax9.invert_xaxis()
ax10.plot(calibfigs['100symb'].sun, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfscalib[500].bp,dfscalib[500].sun)
ax11.invert_xaxis()
ax12.plot(calibfigs['500symb'].sun, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax1.set_ylabel('10 Year Bin', fontsize=20, color='black')
ax3.set_ylabel('20 Year Bin', fontsize=20, color='black')
ax5.set_ylabel('30 Year Bin', fontsize=20, color='black')
ax7.set_ylabel('50 Year Bin', fontsize=20, color='black')
ax9.set_ylabel('100 Year Bin', fontsize=20, color='black')
ax11.set_ylabel('500 Year Bin', fontsize=20, color='black')

f53.tight_layout()
f53.savefig('Calib_Sun_OrigSymb.pdf', bbox_inches='tight')
