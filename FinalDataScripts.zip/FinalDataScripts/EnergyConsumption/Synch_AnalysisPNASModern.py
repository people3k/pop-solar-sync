#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 18 12:36:53 2018

Created on Fri Apr 20 15:06:32 2018

This script is used, together with synchfunctions, to generate the figures for Freeman, Baggio, Robinson et al. "The synchronization of energy consumption by human societies throughout the Holocence"


This script allows for the synch analysis of human energy and solar energy. 

This script analyzses mutual information (or synchronization) between t-series representing energy consumption in different
areas of the world. 

This script provide the final analysis used in 
Freeman, Baggio, Robinson et al. "Global Synchrony of human population and solar energy throughout the Holocene"


@author: Jacopo A. Baggio, 
Department of Political Science and National Center for Integrated Coastal Research, 
University of Central Florida

"""

#General python packages
import seaborn as sns
import matplotlib.pyplot as plt
import os
import pandas as pd
import numpy as np
import scipy as sp

#Functions for calculating symbolic time-series, mutual information, phase locking value, significance of mutual information
#based of markov chain of order 1 are in the following "functions file".
import synchfunctions as sfu

"""
Where files (csv) are kept. This is a local path, if you want to reproduce the analysis, the path needs to change to where
you have saved the datafiles.
"""

wmodern = ('/Users//Documents/A_STUDI/AAA_work/CoupledInfra_LongTermVariance/HumanSyncing/PNASData/TempEnergyMI.csv')

wdirmod =('/Users/jacopo/Documents/A_STUDI/AAA_work/CoupledInfra_LongTermVariance/HumanSyncing/PNASFigs/Modern')

#change directory where you want to save your results

#load data
dfdata = pd.read_csv(wmodern)

#transform time-series in symbolic 
hca  = sfu.symbtransf(dfdata.can)
hen  = sfu.symbtransf(dfdata.eng)
hfr  = sfu.symbtransf(dfdata.fra)
hgr  = sfu.symbtransf(dfdata.ger)
hit  = sfu.symbtransf(dfdata.ita)
hnl  = sfu.symbtransf(dfdata.nl)
hpt  = sfu.symbtransf(dfdata.por)
hsw  = sfu.symbtransf(dfdata.swe)
hsu  = sfu.symbtransf(dfdata.sun)

sequence1 = ['can', 'eng','fra','ger','ita', 'nl', 'por','swe','sun']

#create new object, dataframe, where to store all the symbolic time-series
dfsymbarea= pd.DataFrame({'can': hca, 'eng': hen,  'fra': hfr, 'ger': hgr, 'ita':hit,'nl': hnl,'por': hpt,'swe': hsw, 'sun': hsu})
    
#change sequence of columns, for figure purposes looks better. First western USA, than USA, then other continents, finally solar forcing.
dfsymbarea = dfsymbarea.reindex(columns=sequence1)
    
#create empty array to store results
phasarea= np.zeros((9,9))
    
#Step 2 Caluclate Mutual Information in Bits (sfu.mutual) for areas and for continents
for i in range (0, np.size(dfsymbarea,1)):
    for j in range (0, np.size(dfsymbarea,1)):
        x1 = list(dfsymbarea.iloc[:,i])
        x2 = list(dfsymbarea.iloc[:,j])
        phasarea[i,j] = sfu.mutual(x1,x2)

#as of now, there is a problem as same (3) is not present, but 3 = e in symbolic letters, 
#and so there is no space between integers. This is important to allow the markov chain code to work.    
#transform time-series in symbolic 
hca  = sfu.symbtransflet(dfdata.can)
hen  = sfu.symbtransflet(dfdata.eng)
hfr  = sfu.symbtransflet(dfdata.fra)
hgr  = sfu.symbtransflet(dfdata.ger)
hit  = sfu.symbtransflet(dfdata.ita)
hnl  = sfu.symbtransflet(dfdata.nl)
hpt  = sfu.symbtransflet(dfdata.por)
hsw  = sfu.symbtransflet(dfdata.swe)
hsu  = sfu.symbtransflet(dfdata.sun)

dfsigarea= pd.DataFrame({'can': hca, 'eng': hen,  'fra': hfr, 'ger': hgr, 'ita':hit,'nl': hnl,'por': hpt,'swe': hsw, 'sun': hsu})
#change sequence of columns, for figure purposes looks better. First western USA, than USA, then other continents, finally solar forcing.
dfsigarea = dfsigarea.reindex(columns=sequence1)

#significance value are almost-symmetrical, however, for easier coding, we leave the entrire results. 
#The non-symmetry of the results even after 1000 repetition is a result of the stochasticity 
#inbuild the markov-chain of order 1 process (markc) or in the markov chain order 0 = montecarlo (mark0)
reps = 500
sigarea = np.zeros((reps,9,9))
for r in range (0,reps):
    for i in range (0, np.size(dfsigarea,1)):
        for j in range (0, np.size(dfsigarea,1)): 
            x1 = sfu.markc(dfsigarea.iloc[:,i],0)
            x2 = sfu.markc(dfsigarea.iloc[:,j],0)
            sigarea[r,i,j] = sfu.mutual(x1,x2)

#create matrix to contain the significance value (if above = significant) of the surrogate 
#time-series mutual info for areas
sig95area = np.zeros((9,9))
for i in range (0, np.size(dfsymbarea,1)):
    for j in range (0, np.size(dfsymbarea,1)):
        mu, sigma = np.mean(sigarea[:,i,j]), np.std(sigarea[:,i,j])
        sig95area[i][j] = sp.stats.norm.interval(0.95, loc=mu, scale=sigma)[1]

    
ptri = np.tril(phasarea, k=-1)
ptri[ptri == 0] = np.nan
stri = np.tril(sig95area, k=-1)
stri[stri==0] = np.nan

ptridiag = np.tril(phasarea, k=0)
ptridiag[ptridiag == 0] = np.nan
    
sigperc = sum(sum(i >= 0 for i in (ptri-stri))) / 45 # as 45 = number of entries in the matrix, gives an idea of % significant
avgmi = np.mean (phasarea) #average mutual information
    
#Figures for Paper
            
#labels for symbolic figures. 
symblab = ['Through','Decrease', 'Same','Increase','Peak']

#labels for areas
clabels = ('CA','EN','FR','DE', 'IT','NL','PT','SW','SUN')

#set seaborn context
sns.set(context='paper', style='white', palette='colorblind', font_scale=1)
#create colorbar so it is only one for the figure
im = plt.imshow(np.random.random((10,10)), vmin=0, vmax=1, cmap='Blues')       

if not os.path.exists(wdirmod):
    os.makedirs(wdirmod)
os.chdir(wdirmod)

f1,(ax1) = plt.subplots(1,1, sharey=False, sharex=False,  figsize=(20,20))
    
heat1 = sns.heatmap (ptridiag, annot=True, fmt='.3f', ax=ax1,cmap='Blues',square = True, vmin=0, vmax=1,cbar=True ) 
ax1.set_title ('Modern Mutual Information',fontsize=20, color='black')
ax1.set_xticklabels(clabels,fontsize=14, color='black')
ax1.set_yticklabels(clabels, fontsize=14, color='black', rotation=0)

f1.tight_layout()
f1.savefig('Mod_MI_Area.pdf', bbox_inches='tight')  


#Significance for Areas with Raw Dates at different binning intervals.

f2, axs = plt.subplots(9,9, sharey=False, sharex=False,  figsize=(40,40))
axs.ravel()
for i in range(0,9):
    for j in range (0,9):
        if i<=j:
            axs[i,j].axis('off')
        else:
            axs[i,j].hist(sigarea[:,i,j])
            axs[i,j].set_title(clabels[i] + '-' + clabels[j] + ' ' + 'Significance', fontsize=18, color='black')
            axs[i,j].axvline(x = ptridiag[i,j],color= 'r')
            axs[i,j].axvline(x = sig95area[i,j], color= 'b', linestyle='--')
fig=axs[0,0].figure
fig.text(0.5,-0.01, 'MI between Surrogate Time-Series', ha='center', va='center', fontsize=30 )
fig.text(-0.01,0.5, 'Frequency of MI in Surrogate Time-Series', ha='center', va='center', rotation=90, fontsize=30)

f2.tight_layout()
f2.savefig('ModernSignificance_MI.pdf', bbox_inches='tight') 


f3, ((ax1,ax2),(ax3,ax4),(ax5,ax6),(ax7,ax8),(ax9,ax10),(ax11,ax12),(ax13,ax14),(ax15,ax16),(ax17,ax18)) = plt.subplots(9,2, sharey=False, sharex=False, figsize=(20,20))   

ax1.set_title('Original Energy Consumption',fontsize=24,color='black')
ax2.set_title('Symbolic Transform',fontsize=24,color='black')

ax1.plot(dfdata.can)
ax2.plot(dfsymbarea.can, marker='o')
ax2.invert_xaxis()
ax2.set_yticks([1,2,3,4,5])
ax2.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax3.plot(dfdata.eng)
ax4.plot(dfsymbarea.eng, marker='o')
ax4.invert_xaxis()
ax4.set_yticks([1,2,3,4,5])
ax4.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)


ax5.plot(dfdata.fra)
ax6.plot(dfsymbarea.fra, marker='o')
ax6.invert_xaxis()
ax6.set_yticks([1,2,3,4,5])
ax6.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax7.plot(dfdata.ger)
ax8.plot(dfsymbarea.ger, marker='o')
ax8.invert_xaxis()
ax8.set_yticks([1,2,3,4,5])
ax8.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax9.plot(dfdata.ita)
ax10.plot(dfsymbarea.ita, marker='o')
ax10.invert_xaxis()
ax10.set_yticks([1,2,3,4,5])
ax10.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax11.plot(dfdata.nl)
ax12.plot(dfsymbarea.nl, marker='o')
ax12.invert_xaxis()
ax12.set_yticks([1,2,3,4,5])
ax12.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax13.plot(dfdata.por)
ax14.plot(dfsymbarea.por, marker='o')
ax14.invert_xaxis()
ax14.set_yticks([1,2,3,4,5])
ax14.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)


ax15.plot(dfdata.swe)
ax16.plot(dfsymbarea.swe, marker='o')
ax16.invert_xaxis()
ax16.set_yticks([1,2,3,4,5])
ax16.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)

ax17.plot(dfdata.sun)
ax18.plot(dfsymbarea.sun, marker='o')
ax18.invert_xaxis()
ax18.set_yticks([1,2,3,4,5])
ax18.set_yticklabels(symblab, fontsize=18,color='black',rotation=0)


ax1.set_ylabel('Canada', fontsize=20, color='black')
ax3.set_ylabel('England', fontsize=20, color='black')
ax5.set_ylabel('France', fontsize=20, color='black')
ax7.set_ylabel('Germany', fontsize=20, color='black')
ax9.set_ylabel('Italy', fontsize=20, color='black')
ax11.set_ylabel('Netherlands', fontsize=20, color='black')
ax13.set_ylabel('Portugal', fontsize=20, color='black')
ax15.set_ylabel('Sweden', fontsize=20, color='black')
ax17.set_ylabel('Solar Forcing', fontsize=20, color='black')

f3.tight_layout()
f3.savefig('Modern_Orig_Symb.pdf', bbox_inches='tight')
