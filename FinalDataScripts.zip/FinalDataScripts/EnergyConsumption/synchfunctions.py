#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 16 11:09:15 2018

This script is used, together with Synch_PnasRev.

This script allows for the synch analysis of human energy and solar energy between 10400 and 400 years ago. 

This script contains the main function to assess mutual information (as well as empirical mode decomposition) to assess
whether time-series are synchronized in phase or not (i.e. have the same rithm or go up and down together)

This script analyzses mutual information (or synchronization) between t-series representing energy consumption in different
areas of the world binned at 10, 20, 30, 50, 100, 500 and 1000 years. 

This script provides the  analysis used in 
Freeman, Baggio, Robinson et al. "The synchronization of energy cosumption by human societies throughout the Holocene"


@author: Jacopo A. Baggio, 
Department of Political Science and National Center for Integrated Coastal Research, 
University of Central Florida
"""
#necessary python packages to import for the functions to work.
import numpy as np
from pyitlib import discrete_random_variable as drv  #to calculate joint entropy
import math
#from collections import Counter
#to assess phase locking value, we assess empirical mode decomposition and assess PLV at difference mode functions(IMF)
from pyhht import EMD #empirical mode decomposition



"""calculate shannon-entropy of symbolic time series - i.e. how many questions do i need, 
on average, to get every single "state" of the time-series? 
"""
def entr(zz):
    #make set with all unrepeatable symbols from string
    dct = dict.fromkeys(list(zz))
    #calculate frequencies
    probs =  [float(zz.count(cat)) / len(zz) for cat in dct]
    #calculate Entropy
    H = -sum([pr  * math.log2(pr) for pr in probs ])
    return H

#calculate joint entropy with drv.entropy_joint
    
#Calcualte mutual information  via chain rule (raw mutual information)
def mutual (hx,hy):
   jointentr = drv.entropy_joint([hx,hy]) 
   mi = entr(hx) + entr(hy) - jointentr
   return mi

"""
use uncertainty coefficient to assess different normalization type for mutual info - 
it is a way to normalize mutual-info so it assumes values in the [0,1] interval. 
It is interpreted as: if i know time-series X how much can i reduce the uncertainty in predicting time-series Y?
"""
def ucoeff (hx,hy):
   mi = mutual(hx,hy)
   norm = entr(hx) + entr(hy)
   return 2 * (mi / norm) 

"""
function for symbolic trasnformation of time-series. 
Using integers makes it easier to graph symblic t-s and does not have
any actual effect on entropy and mutual information.

 Through point: x(t+1) < x(t) <= x(t+2)  = A or 1
 Through point: x(t+1) < x(t+2) <= x(t)  = A or 1
 Peak point   : x(t) < x(t+2) <= x(t+1)  = C or 5
 Peak point   : x(t+2) < x(t) <= x(t+1)  = C or 5
 Peak Point   : x(t+2) <= x(t) < x(t+1)  = C or 5
 Increase     : x(t) <= x(t+1) < x(t+2)  = B or 4
 Decrease     : x(t+2) <= x(t+1) < x(t)  = D or2
 No Change    : x(t) = x(t+1) = x(t+2)   = E or 3

"""
def symbtransf (x):
    hx = []
    #x is a vector or a series
    ll = np.size(x,axis = 0)
    for i in range(0,ll-2):
        if (x[i+1] < x[i] <= x[i+2]) :
            hx.append (1)
        elif (x[i+1] < x[i+2] <= x[i]):
            hx.append (1)
        elif (x[i] < x[i+2] <= x[i+1]) :
            hx.append (5)
        elif (x[i+2] < x[i] <= x[i+1]):
            hx.append (5)
        elif (x[i+2] <= x[i] < x[i+1]):
            hx.append (5)
        elif (x[i] <= x[i+1] < x[i+2]):
            hx.append (4)
        elif (x[i+2] <= x[i+1] < x[i]):
            hx.append (2)
        elif (x[i] == x[i+1] == x[i+2]):
            hx.append (3)
    return hx


def symbtransflet (x):
    hx = []
    #x is a vector or a series
    ll = np.size(x,axis = 0)
    for i in range(0,ll-2):
        if (x[i+1] < x[i] <= x[i+2]) :
            hx.append ('a')
        elif (x[i+1] < x[i+2] <= x[i]):
            hx.append ('a')
        elif (x[i] < x[i+2] <= x[i+1]) :
            hx.append ('c')
        elif (x[i+2] < x[i] <= x[i+1]):
            hx.append ('c')
        elif (x[i+2] <= x[i] < x[i+1]):
            hx.append ('c')
        elif (x[i] <= x[i+1] < x[i+2]):
            hx.append ('b')
        elif (x[i+2] <= x[i+1] < x[i]):
            hx.append ('d')
        elif (x[i] == x[i+1] == x[i+2]):
            hx.append ('e')
    return hx

"""
calculate initial probabilities for a time-series, to develop surrogate time-series based on markov-chains
works only for symbolic time-series. Works with list objects, 
so make sure that if you have a dataframe you use (list (df.variable)) as hx
"""
def initial_state (xy,numerical):
    if numerical == 1:
        xy1 = []
        for i in xy:
            xy1.append(chr(i))
        dct = dict.fromkeys(list(xy1))
        #calculate frequencies
        probs =  [float(xy1.count(cat)) / len(xy) for cat in dct]
    else:
        dct = dict.fromkeys(list(xy))
        #calculate frequencies
        probs =  [float(xy.count(cat)) / len(xy) for cat in dct]
    return probs

"""   
To change a symbolic or string to numeric for transition matrix calculations we need the letter we are interested in and
the first letter we are using, in our case 'a'
"""
def rank(c,start):
    return ord(c) - ord(start)


"""
The following function checks whether the symbolic list is sequential, not needed here.
"""
def checker(li):
    it=iter(li[1:])
    return all((next(it))-(i)==1 for i in li[:-1])

"""
Create transition  matrix for markov chains to create surrogate time-series. 
It works with integer and symbolic time-series
If the t-s is represented by integers, make sure it starts at 0 and integer representing different states 
are sequential (not 0,10, but 0,1, not 0,7,10, but 0,1,2 etc..)

If symbolic, the series is transformed in integer starting at 0. 
Again, letter should be sequential as above, and the first letter is substracted so that the integer resulting
starts at 0 as the integer. 
"""
def transmat(trans,numerical):
    tnum = []
    if numerical == 1:
        tn1 = trans - min(trans) #make sure the series has states taking value in the integer number ensemble and starting at 0. One should not have "jumps"
        n = 1+ max(tn1) #number of states
        tnum = tn1
    else :
        for i in trans:
            tnum.append(rank(i, 'a'))
        n = 1+max(tnum)
    
    
    M = [[0]*n for _ in range(n)]
    for (i,j) in zip(tnum,tnum[1:]):
        M[i][j] += 1
    #now convert to probabilities:
    for row in M:
        s = sum(row)
        if s > 0:
            row[:] = [f/s for f in row]
    return M

#random initialization of markov chain if initial prob vector is provided (from initial_state)
def randinit(xx):
    t = np.random.random()
    for i,p in enumerate(np.cumsum(xx)):
        if p > t: 
            return i
        
"""
generating surrogate time-series by starting based on frequencies in original time-series.
marc = generates surrogate time series based on markov chain of order 1
mark0 = generates surrogate time series based on markov chains of order 0 (i.e. monte-carlo, where each event is independent from the previous one)            
"""
def markc (hy, numerical) :
    le   = np.size(hy)
    mt   = transmat(hy, numerical)   
    init = initial_state(list(hy),numerical) 
    surr = []
    s = randinit(init)
    # Walk in chain
    for i in range(0, le):
       s = randinit(mt[s])
#this bit of code is very rare, but there are cases, when some of the values are missing 
#(i.e. the sequence is 0,5 but 3 is never there) when s returns a None value, 
#in that case, we use a markov chain order 0 process to evaluate s again and continue then with order 1 markov chain.
       if s == None:          
           s = randinit(init)
     #append the values      
       surr.append(s)
    return surr

#
def mark0 (hx, numerical):
    le = np.size (hx)
    surr = []
    prob_s = initial_state(list(hx),numerical) 
    for i in range (0,le):
        s = randinit(prob_s)
        surr.append(s)
    return surr
    

"""
EMD Decomposition

From Huang et al. 1998 
"In practice, the EMD is implemented through a sifting process that uses only local extrema.
Although some of the extrinsic functions used in fitting data, such as exponential, power law, 
and hyperbolic baselines, are nonlinear models, there is no guarantee that the externally determined 
nonlinearity characteristics correspond to those embedded in the mechanisms generating the data. 
As most of the underlying mechanisms of either natural or human-induced variability are only incompletely known, 
it is almost impossible to decide which of the myriad functions to choose so as to render 
the best extrinsically determined trend. Therefore, to have a meaningful trend, the method 
has to be adaptive (so as to let nature speak for itself). The EMD method fits these requirements well."

Other explanation (from Python pyHHT package)
The EMD is an iterative algorithm which breaks a signal down into IMFs. The process is performed as follows:
1. Find all local extrema in the signal.
2. Join all the local maxima with a cubic spline, creating an upper envelope. Repeat for local minima and create a lower envelope.
3. Calculate the mean of the envelopes.
4. Subtract mean from original signals.
5. Repeat steps 1-4 until result is an IMF.
6. Subtract this IMF from the original signal.
7. Repeat steps 1-6 till there are no more IMFs left in the signal.

IMF = implicit mode function, the highest imf is the residual. the lowest two are often noise. 

IMF satisfies two conditions:
 1 ) the number of extrema and the number of zero crossing differs only by one and
 2) the local average is zero. The condition that the local average is zero implies 
 that envelop mean of upper envelop and lower envelop is zero.

EMD references:

Huang, N. E., Shen, Z., Long, S. R., Wu, M. C., Shih, H. H., Zheng, Q., ... & Liu, H. H. (1998, March). The empirical mode decomposition and the Hilbert spectrum for nonlinear and non-stationary time series analysis. In Proceedings of the Royal Society of London A (Vol. 454, No. 1971, pp. 903-995).
Wu, Z., Huang, N. E., Long, S. R., & Peng, C. K. (2007). On the trend, detrending, and variability of nonlinear and nonstationary time series. Proceedings of the National Academy of Sciences, 104(38), 14889-14894.
Rato R.T., Ortigueira M.D., Batista A.G 2008 ‘On the HHT, its problems, and some solutions.’ Mechanical Systems and Signal Processing 22 1374-1394


The following calculates the hilbert-huang transform of a specific mode (or IMF) and takes the derivative (angle) so that 
it is possible to calculate a phase locking value between time-series

"""

def phtransf (hx,mode):
    decom = EMD(hx).decompose()
    res = np.angle(decom[mode])
    return res   
    
#calculate phase locking value. Based on Kuramoto synchronization work. This ensures that synch with itself = 1
def plv1 (hx,hy):
    plv = 1-np.abs((np.sum(np.exp(np.complex(0,1))*(hx-hy)))/np.size(hx))
    return plv

#in this case, synch with itself = 0 
def plv2 (hx,hy):
    Inst_phase_diff=hx-hy
    avg_phase=np.average(Inst_phase_diff)
    return avg_phase
