Metadata for summary files Freeman et al. 2018 ``The synchronization of energy consumption by human societies throughout the Holocence"

There are five data fil and one pdf file in this directory. The data files are all .csv: PairwiseCalMI, PairwiseCalSPBoot, PairwiseCalSPStand, pairwiseEU and FinalSolarSum. The first three data files summarize mutual information and Spearman's correlation values between energy consumption records. FinalSolarSum summarizes mean mutual information between radiocarbon and solar records at different bin widths.
######################################
File-PairwiseCalMI:
MI-mutual information
NullMI-95th percential of all null mutual information values constructed from surrogate time-series
Pair and Pair2-pair of records associated
Continent and Continent2-ID variable whether a paire is from the same or a different continent
Extent and Extent2-Ranking of distance between records
UCoEf-Normalized mutual information value (uncertainty coefficient)
Bin-Bin size at which calibrated summed probability distributions were aggregated. 
Sig-1=MI>NullMI
Niche-Marker of whether pairs of sequences both adopted agriculture prehistorically
##############################################################
File-PairwiseCalSp
Rh-Spearman's correlation coefficient
Pair-pair of records associated
Continent-ID variable whether a paire is from the same or a different continent
Extent-Ranking of distance between records
Bin-Bin size at which calibrated summed probability distributions were aggregated. 
Sig-1=MI>NullMI
Niche-Marker of whether pairs of sequences both adopted agriculture prehistorically
##########################################################
File-pairwiseEU
Rh-Spearman's correlation coefficient
MI-mutual information. Note there are lags up to six years in this file. X.MI is negative lage, MI.X is a positive lag.
NullMI-95th percential of all null mutual information values constructed from surrogate time-series. Lag structure the same as above.
Pair-pair of records associated
Continent-ID variable whether a paire is from the same or a different continent
Extent-Ranking of distance between records
Sig-1=MI>NullMI. This is calculated for all lags combined.
######################################################
File-FinalSolarSum
MI-Mean mutual information between radiocarbon records and soral energy
Bin-Bin size at which calibrated summed probability distributions were aggregated
