###Make summary plot used in the main text of Freeman et al. 2018
##Human Syncing Paper
library(ggplot2)
library(plyr)
library(scales)
library(reshape2)
library(splines)


#1. Make box plots and and bar graphs that compar MI and Rh coefficients and
#percent of cases with significant values. This analysis is for calibrated radiocarbon dates

MIComp<-read.csv(file="PairwiseCalMI.csv", header=T)

p <- ggplot(MIComp, aes(factor(Continent), (MI)))
p +  stat_boxplot(geom ='errorbar') + 
  geom_boxplot(fill = "slateblue3", colour = "black", notch=FALSE)+
  #ylim(0.2, 1)+
  #scale_y_continuous(trans="log", labels = comma_format(digits = 1))+
  #coord_flip() +
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.5), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Distance ranking", y="Pairwise mutual information values")+
  facet_wrap(~Bin)

##Mann-Whittney U test
wilcox.test(MI ~ Continent, data=MIComp) 

##Export the plot
pdf("MIExtentFinalCal.pdf")
p <- ggplot(MIComp, aes(factor(Continent), (MI)))
p +  stat_boxplot(geom ='errorbar') + 
  geom_boxplot(fill = "slateblue3", colour = "black", notch=FALSE)+
  #ylim(0.2, 1)+
  #scale_y_continuous(trans="log", labels = comma_format(digits = 1))+
  #coord_flip() +
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Pairwise mutual information values")
#facet_wrap(~Continent)

dev.off()

##Bar plots of significance by continent comparison

myFunc = function(x) {
  result = (sum(x)/length(x))
  result
}

p <- ggplot(MIComp, aes(factor(Continent), (Sig)))
p + stat_summary(fun.y = "myFunc", geom = "bar", fill = "slateblue3", color="black", size = 1) + 
 # stat_summary(fun.data = "myFunc")+
  theme_bw()+
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Proportion of significant MI values")
 # facet_wrap(~Bin)


##Export the plot
pdf("MISigContinentCal.pdf")
p <- ggplot(MIComp, aes(factor(Continent), (Sig)))
p + stat_summary(fun.y = "myFunc", geom = "bar", fill = "slateblue3", color="black", size = 1) + 
  # stat_summary(fun.data = "myFunc")+
  theme_bw()+
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Number of significant MI values")
# facet_wrap(~Bin)
dev.off()

###Correlation Spreaman's (Rh)
CorComp<-read.csv(file="PairwiseCalSp.csv", header=T)

p <- ggplot(CorComp, aes(factor(Continent), (Rh)))
p +  stat_boxplot(geom ='errorbar') + 
  geom_boxplot(fill = "slateblue3", colour = "black", notch=FALSE)+
  #ylim(0.2, 1)+
  #scale_y_continuous(trans="log", labels = comma_format(digits = 1))+
  #coord_flip() +
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Pairwise Spearman's correlations")
#facet_wrap(~Bin)

##Mann-Whittney U test
wilcox.test(Rh ~ Continent, data=CorComp) 

##Export the plot
pdf("RhExtentFinal.pdf")
p <- ggplot(CorComp, aes(factor(Extent), (Rh)))
p +  stat_boxplot(geom ='errorbar') + 
  geom_boxplot(fill = "slateblue3", colour = "black", notch=FALSE)+
  #ylim(0.2, 1)+
  #scale_y_continuous(trans="log", labels = comma_format(digits = 1))+
  #coord_flip() +
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Pairwise Spearman's correlations")
#facet_wrap(~Bin)
dev.off()


##################################################################################33
#2. Historical EU Energy Connsumption Summary Plots

MICompEU<-read.csv(file="pairwiseEU.csv", header=T)

p <- ggplot(MICompEU, aes(factor(Continent), (MI)))
p +  stat_boxplot(geom ='errorbar') + 
  geom_boxplot(fill = "slateblue3", colour = "black", notch=FALSE)+
  #ylim(0.2, 1)+
  #scale_y_continuous(trans="log", labels = comma_format(digits = 1))+
  #coord_flip() +
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Pairwise mutual information values")
#facet_wrap(~Bin)

##Mann-Whittney U test
wilcox.test(MI ~ Continent, data=MICompEU) 

##Export the plot
pdf("MIContinentEU.pdf")
p <- ggplot(MICompEU, aes(factor(Continent), (MI)))
p +  stat_boxplot(geom ='errorbar') + 
  geom_boxplot(fill = "slateblue3", colour = "black", notch=FALSE)+
  #ylim(0.2, 1)+
  #scale_y_continuous(trans="log", labels = comma_format(digits = 1))+
  #coord_flip() +
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Pairwise mutual information values")
#facet_wrap(~Bin)
dev.off()

##Bar plots of significance by continent comparison

#Calculate proportion
myFunc = function(x) {
  result = (sum(x)/length(x))
  result
}

p <- ggplot(MICompEU, aes(factor(Extent), (Sig)))
p + stat_summary(fun.y = "myFunc", geom = "bar", fill = "slateblue3", color="black", size = 1) + 
  # stat_summary(fun.data = "myFunc")+
  theme_bw()+
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Distance ranking", y="Proportion of significant MI values")
# facet_wrap(~Bin)

##Export the plot
pdf("MISigContinentEU.pdf")
p <- ggplot(MIComp, aes(factor(Continent), (Sig)))
p + stat_summary(fun.y = "myFunc", geom = "bar", fill = "slateblue3", color="black", size = 1) + 
  # stat_summary(fun.data = "myFunc")+
  theme_bw()+
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Number of significant MI values")
# facet_wrap(~Bin)
dev.off()

###Correlation Spreaman's (Rh)
p <- ggplot(MICompEU, aes(factor(Continent), (Rh)))
p +  stat_boxplot(geom ='errorbar') + 
  geom_boxplot(fill = "slateblue3", colour = "black", notch=FALSE)+
  #ylim(0.2, 1)+
  #scale_y_continuous(trans="log", labels = comma_format(digits = 1))+
  #coord_flip() +
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Pairwise Spreaman's correlations")
#facet_wrap(~Bin)

##Mann-Whittney U test
wilcox.test(Rh ~ Continent, data=MICompEU) 

##Export graphic to working folder
pdf("RhContinentEU.pdf")
p <- ggplot(MICompEU, aes(factor(Continent), (Rh)))
p +  stat_boxplot(geom ='errorbar') + 
  geom_boxplot(fill = "slateblue3", colour = "black", notch=FALSE)+
  #ylim(0.2, 1)+
  #scale_y_continuous(trans="log", labels = comma_format(digits = 1))+
  #coord_flip() +
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.7), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Continent comparison groups", y="Pairwise Spreaman's correlations")
dev.off()


#######################################################################################

#3. SOLAR SUMMARY
Sun<-read.csv(file="FinalSolarSum.csv", header=T)

#Order factor names by the way they are listed in the spread sheet
Sun$Bin <- as.character(Sun$Bin)
#Then turn it back into an ordered factor
Sun$Bin <- factor(Sun$Bin, levels=unique(Sun$Bin))

myFunc = function(x) {
  result = c(mean(x)-sd(x)/(sqrt(length(x))), mean(x) + sd(x)/(sqrt(length(x))))
  names(result) = c("ymin", "ymax")
  result
}

p <- ggplot(Sun, aes(factor(Bin), (MI)))
p + stat_summary(fun.y = mean, geom = "bar", fill = "SlateBlue3", color="black", size = 1) + 
  stat_summary(fun.data = "myFunc", geom = "errorbar", width = 0.1)+
  theme_bw()+
  theme(axis.text = element_text(size = rel(1.2), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "Bin width", y="Mean mutual information")


