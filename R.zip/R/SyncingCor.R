library(reshape2)
library(ggplot2)
library(plyr)
library(scales)
library(MASS)
library(splines)
library(synchrony)
library(PerformanceAnalytics)
#Set working directory to file location

#100 YEAR BINS##########################################################
#load csv for 100 year bins 

data4<-read.csv(file="SyncData1.csv", header=T)

###Basic Graph of z-scores
    #   Calculate z-scores
  x<-data4$bp
  z1<-((data4$ariz-mean(data4$ariz))/(sqrt(sd(data4$ariz))))
  z2<-((data4$cali-mean(data4$cali))/(sqrt(sd(data4$cali))))
  z3<-((data4$colo-mean(data4$colo))/(sqrt(sd(data4$colo))))
  z4<-((data4$nmex-mean(data4$nmex))/(sqrt(sd(data4$nmex))))
  z5<-((data4$neva-mean(data4$neva))/(sqrt(sd(data4$neva))))
  z6<-((data4$utah-mean(data4$utah))/(sqrt(sd(data4$utah))))
  z7<-((data4$wyom-mean(data4$wyom))/(sqrt(sd(data4$wyom))))
  z8<-((data4$chile-mean(data4$chile))/(sqrt(sd(data4$chile))))
  z9<-((data4$aus-mean(data4$aus))/(sqrt(sd(data4$aus))))
  z10<-((data4$uk-mean(data4$uk))/(sqrt(sd(data4$uk))))
  z11<-((data4$usa-mean(data4$usa))/(sqrt(sd(data4$usa))))
  z12<-((data4$sun-mean(data4$sun))/(sqrt(sd(data4$sun))))
###
#Make date frame
df <- data.frame(x, z1,z2,z3,z4,z5,z6,z7,z8,z9,z10)
#df<- data.frame(x,z14,z12)

# melt the data to a long format
df2 <- melt(data = df, id.vars = "x")

####Graph the z-scores
p<-ggplot(data = df2, aes(x = x, y = value, color=variable))+ 
  geom_line()+
  xlim(400, 10000)+
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.9), colour = "black"), axis.title=element_text(size=16))+
  labs(x = "Time (Years cal BP)", y="Z-score of radiocarbon frequency")
# geom_smooth(method='lm', formula=y ~ ns(x, 13), se=FALSE)
p

###SW Area Plot
x<-data4$bp
z1<-(((data4$ariz+data4$nmex+data4$colo+data4$utah))-mean((data4$ariz+data4$nmex+data4$colo+data4$utah)))/(sqrt(sd((data4$ariz+data4$nmex+data4$colo+data4$utah))))
z12<-((data4$sun-mean(data4$sun))/(sqrt(sd(data4$sun))))
df<- data.frame(x,z1,z12)

df2 <- melt(data = df, id.vars = "x")

####Graph the z-scores
p<-ggplot(data = df2, aes(x = x, y = value, fill=variable))+ 
  geom_area()+
  xlim(400, 10000)+
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.9), colour = "black"), axis.title=element_text(size=16))+
  labs(x = "Time (Years cal BP)", y="Z-score of radiocarbon/sunspot frequency")
#geom_smooth(method='lm', formula=y ~ ns(x, 13), se=FALSE)
p
######Print pdf file of plot
pdf("SWArea.pdf")
p
dev.off()

  ###Mean Community wide Spearman's Correlations using the synchrony package and pairwise correlations
    #100 year bins

    #Pairwise correlation
    data5 <- cbind((data4$nmex), (data4$ariz),(data4$colo), (data4$cali), (data4$utah), (data4$neva), (data4$wyom), data4$chile, data4$aus, data4$uk) 
    chart.Correlation(data5, method="spearman", cex.axis=1.4)

    #Mean Community correlation
    data6<-as.matrix(data5)
    synch<-meancorr(data6, nrands = 2000, method = "spearman", type = 2, quiet = TRUE)
    synch

#200 YEAR BINS###################################################################################
    data4<-read.csv(file="SyncData2.csv", header=T)
    
    ###Basic Graph of z-scores
    #   Calculate z-scores
    x<-data4$bp
    z1<-((data4$ariz-mean(data4$ariz))/(sqrt(sd(data4$ariz))))
    z2<-((data4$cali-mean(data4$cali))/(sqrt(sd(data4$cali))))
    z3<-((data4$colo-mean(data4$colo))/(sqrt(sd(data4$colo))))
    z4<-((data4$nmex-mean(data4$nmex))/(sqrt(sd(data4$nmex))))
    z5<-((data4$neva-mean(data4$neva))/(sqrt(sd(data4$neva))))
    z6<-((data4$utah-mean(data4$utah))/(sqrt(sd(data4$utah))))
    z7<-((data4$wyom-mean(data4$wyom))/(sqrt(sd(data4$wyom))))
    z8<-((data4$chile-mean(data4$chile))/(sqrt(sd(data4$chile))))
    z9<-((data4$aus-mean(data4$aus))/(sqrt(sd(data4$aus))))
    z10<-((data4$uk-mean(data4$uk))/(sqrt(sd(data4$uk))))
    z11<-((data4$usa-mean(data4$usa))/(sqrt(sd(data4$usa))))
    z12<-((data4$sun-mean(data4$sun))/(sqrt(sd(data4$sun))))
    ###
    #Make date frame
    df <- data.frame(x, z1,z2,z3,z4,z5,z6,z7,z8,z9,z10)
    #df<- data.frame(x,z14,z12)
    
    # melt the data to a long format
    df2 <- melt(data = df, id.vars = "x")
    
    ####Graph the z-scores
    p<-ggplot(data = df2, aes(x = x, y = value, color=variable))+ 
      geom_line()+
      xlim(400, 10000)+
      theme_bw() +
      theme(axis.text = element_text(size = rel(1.9), colour = "black"), axis.title=element_text(size=16))+
      labs(x = "Time (Years cal BP)", y="Z-score of radiocarbon frequency")
    # geom_smooth(method='lm', formula=y ~ ns(x, 13), se=FALSE)
    p
    
    
    pdf("GraphName.pdf")
    p
    dev.off()
    
    ##########Mean Community wide Spearman's Correlations using the synchrony package and pairwise correlations
    #200 year bins
    
    #Pairwise correlation
    data5 <- cbind((data4$nmex), (data4$ariz),(data4$colo), (data4$cali), (data4$utah), (data4$neva), (data4$wyom), data4$chile, data4$aus, data4$uk) 
    chart.Correlation(data5, method="spearman", cex.axis=1.4)
    
    #Mean Community correlation
    data6<-as.matrix(data5)
    synch<-meancorr(data6, nrands = 2000, method = "spearman", type = 2, quiet = TRUE)
    synch
    
#300 YEAR BINS
  
    data4<-read.csv(file="SyncData3.csv", header=T)
    
    ###Basic Graph of z-scores
    #   Calculate z-scores
    x<-data4$bp
    z1<-((data4$ariz-mean(data4$ariz))/(sqrt(sd(data4$ariz))))
    z2<-((data4$cali-mean(data4$cali))/(sqrt(sd(data4$cali))))
    z3<-((data4$colo-mean(data4$colo))/(sqrt(sd(data4$colo))))
    z4<-((data4$nmex-mean(data4$nmex))/(sqrt(sd(data4$nmex))))
    z5<-((data4$neva-mean(data4$neva))/(sqrt(sd(data4$neva))))
    z6<-((data4$utah-mean(data4$utah))/(sqrt(sd(data4$utah))))
    z7<-((data4$wyom-mean(data4$wyom))/(sqrt(sd(data4$wyom))))
    z8<-((data4$chile-mean(data4$chile))/(sqrt(sd(data4$chile))))
    z9<-((data4$aus-mean(data4$aus))/(sqrt(sd(data4$aus))))
    z10<-((data4$uk-mean(data4$uk))/(sqrt(sd(data4$uk))))
    z11<-((data4$usa-mean(data4$usa))/(sqrt(sd(data4$usa))))
    z12<-((data4$sun-mean(data4$sun))/(sqrt(sd(data4$sun))))
    ###
    #Make date frame
    df <- data.frame(x, z1,z2,z3,z4,z5,z6,z7,z8,z9,z10)
    #df<- data.frame(x,z14,z12)
    
    # melt the data to a long format
    df2 <- melt(data = df, id.vars = "x")
    
    ####Graph the z-scores
    p<-ggplot(data = df2, aes(x = x, y = value, color=variable))+ 
      geom_line()+
      xlim(400, 10000)+
      theme_bw() +
      theme(axis.text = element_text(size = rel(1.9), colour = "black"), axis.title=element_text(size=16))+
      labs(x = "Time (Years cal BP)", y="Z-score of radiocarbon frequency")
    # geom_smooth(method='lm', formula=y ~ ns(x, 13), se=FALSE)
    p
    
    
    pdf("GraphName.pdf")
    p
    dev.off()
    
    ##########Mean Community wide Spearman's Correlations using the synchrony package and pairwise correlations
    #300 year bins
    
    #Pairwise correlation
    data5 <- cbind((data4$nmex), (data4$ariz),(data4$colo), (data4$cali), (data4$utah), (data4$neva), (data4$wyom), data4$chile, data4$aus, data4$uk) 
    chart.Correlation(data5, method="spearman", cex.axis=1.4)
    
    #Mean Community correlation
    data6<-as.matrix(data5)
    synch<-meancorr(data6, nrands = 2000, method = "spearman", type = 2, quiet = TRUE)
    synch
